package com.solveria.core.iam.application.command;

public record CreateRoleCommand(String name, String description) {}
