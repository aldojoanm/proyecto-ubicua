package com.solveria.core.iam.application.query;

public record GetRoleByIdQuery(Long roleId) {}
