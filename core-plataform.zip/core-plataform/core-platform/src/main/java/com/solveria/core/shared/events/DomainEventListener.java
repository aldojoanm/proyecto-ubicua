package com.solveria.core.shared.events;

public class DomainEventListener {
}
