-- Flyway V14: Part E – B2C Interactions (Favorites, Interests, Reviews, Reports, Push Queue)
-- Depends on: V2 tenants, V5 businesses, V4 app schema for RLS

-- -------------------------------------------------------------------
-- user_favorites: users mark favorite businesses (used by B2C + ranking)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_favorites (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  user_id            UUID NOT NULL, -- IAM user UUID
  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_user_fav UNIQUE (tenant_id, user_id, business_id)
);

CREATE INDEX IF NOT EXISTS idx_user_fav_tenant_user
  ON user_favorites(tenant_id, user_id);

CREATE INDEX IF NOT EXISTS idx_user_fav_tenant_business
  ON user_favorites(tenant_id, business_id);

-- -------------------------------------------------------------------
-- user_interest_subscriptions: "Me interesa" => allow push notifications from business
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_interest_subscriptions (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  user_id            UUID NOT NULL,
  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  channel            TEXT NOT NULL DEFAULT 'push'
    CHECK (channel IN ('push','email','whatsapp_optin')),

  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','paused','unsubscribed')),

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_interest UNIQUE (tenant_id, user_id, business_id, channel)
);

CREATE INDEX IF NOT EXISTS idx_interest_tenant_business
  ON user_interest_subscriptions(tenant_id, business_id, status);

CREATE INDEX IF NOT EXISTS idx_interest_tenant_user
  ON user_interest_subscriptions(tenant_id, user_id, status);

-- -------------------------------------------------------------------
-- reviews: user reviews of businesses (moderated)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reviews (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id            UUID NOT NULL,

  rating             SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment            TEXT NULL,

  status             TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','published','hidden','rejected')),

  moderated_by       UUID NULL,
  moderated_at       TIMESTAMPTZ NULL,
  moderation_reason  TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_review_one_per_user UNIQUE (tenant_id, business_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_reviews_tenant_business_status
  ON reviews(tenant_id, business_id, status);

CREATE INDEX IF NOT EXISTS idx_reviews_tenant_user
  ON reviews(tenant_id, user_id);

-- -------------------------------------------------------------------
-- content_reports: reporting inappropriate content (business, review, post, comment, etc.)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS content_reports (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  reporter_user_id   UUID NOT NULL,

  entity_type        TEXT NOT NULL
    CHECK (entity_type IN ('business','review','social_post','social_comment','event','promotion')),

  entity_id          UUID NOT NULL,

  reason             TEXT NOT NULL,
  details            TEXT NULL,

  status             TEXT NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','triaged','closed','rejected')),

  triaged_by         UUID NULL,
  triaged_at         TIMESTAMPTZ NULL,
  resolution_notes   TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_reports_tenant_status_time
  ON content_reports(tenant_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_reports_entity
  ON content_reports(tenant_id, entity_type, entity_id);

-- -------------------------------------------------------------------
-- push_notifications: logical queue (actual delivery via notification service)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS push_notifications (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  target_user_id     UUID NULL, -- NULL => broadcast or segment (defined in payload)
  business_id        UUID NULL REFERENCES businesses(id) ON DELETE SET NULL,

  title              TEXT NOT NULL,
  body               TEXT NOT NULL,
  payload_json       JSONB NOT NULL DEFAULT '{}'::jsonb,

  status             TEXT NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued','sent','failed','cancelled')),

  scheduled_at       TIMESTAMPTZ NULL,
  sent_at            TIMESTAMPTZ NULL,
  failure_reason     TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_push_tenant_status_sched
  ON push_notifications(tenant_id, status, scheduled_at);

CREATE INDEX IF NOT EXISTS idx_push_tenant_user
  ON push_notifications(tenant_id, target_user_id);
