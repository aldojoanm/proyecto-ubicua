-- Flyway V15: Part E – Search Tracking + Metrics + Premium Placements
-- These tables support analytics, IA ranking, and monetization.

-- -------------------------------------------------------------------
-- search_queries: store each search request (for analytics + AI)
-- geo is stored as GEOGRAPHY(Point,4326) (postgis)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS search_queries (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  user_id            UUID NULL,
  query_text         TEXT NOT NULL,

  geo                GEOGRAPHY(Point, 4326) NULL,
  filters_json       JSONB NOT NULL DEFAULT '{}'::jsonb,

  results_count      INT NULL CHECK (results_count IS NULL OR results_count >= 0),

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL
);

CREATE INDEX IF NOT EXISTS idx_search_tenant_time
  ON search_queries(tenant_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_search_geo_gist
  ON search_queries USING GIST (geo);

-- -------------------------------------------------------------------
-- business_metrics_daily: daily aggregated counters (batch job flush from Redis)
-- PK: (tenant_id, business_id, date)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS business_metrics_daily (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  date               DATE NOT NULL,

  views              BIGINT NOT NULL DEFAULT 0,
  click_whatsapp     BIGINT NOT NULL DEFAULT 0,
  click_call         BIGINT NOT NULL DEFAULT 0,
  click_navigate     BIGINT NOT NULL DEFAULT 0,
  favorites          BIGINT NOT NULL DEFAULT 0,
  interests          BIGINT NOT NULL DEFAULT 0,

  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),

  version            BIGINT NOT NULL DEFAULT 0,

  PRIMARY KEY (tenant_id, business_id, date)
);

CREATE INDEX IF NOT EXISTS idx_metrics_daily_business_date
  ON business_metrics_daily(tenant_id, business_id, date DESC);

-- -------------------------------------------------------------------
-- premium_placements: paid boosts that influence ranking / visibility
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS premium_placements (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  placement_type     TEXT NOT NULL
    CHECK (placement_type IN ('search_boost','home_featured','category_featured','event_featured')),

  starts_at          TIMESTAMPTZ NOT NULL,
  ends_at            TIMESTAMPTZ NOT NULL,

  weight             INT NOT NULL DEFAULT 100 CHECK (weight BETWEEN 0 AND 1000),

  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','paused','expired','archived')),

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT ck_premium_time CHECK (starts_at < ends_at)
);

CREATE INDEX IF NOT EXISTS idx_premium_tenant_type_time
  ON premium_placements(tenant_id, placement_type, starts_at, ends_at);

CREATE INDEX IF NOT EXISTS idx_premium_tenant_business
  ON premium_placements(tenant_id, business_id);
