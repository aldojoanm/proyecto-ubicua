-- Flyway V16: Part E – RLS enable + baseline tenant policies
-- Uses app.current_tenant_id() from V4.

ALTER TABLE user_favorites             ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_interest_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews                    ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_reports            ENABLE ROW LEVEL SECURITY;
ALTER TABLE push_notifications          ENABLE ROW LEVEL SECURITY;

ALTER TABLE search_queries             ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_metrics_daily     ENABLE ROW LEVEL SECURITY;
ALTER TABLE premium_placements         ENABLE ROW LEVEL SECURITY;

-- user_favorites
DROP POLICY IF EXISTS user_favorites_isolation ON user_favorites;
CREATE POLICY user_favorites_isolation ON user_favorites
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- interests
DROP POLICY IF EXISTS user_interest_isolation ON user_interest_subscriptions;
CREATE POLICY user_interest_isolation ON user_interest_subscriptions
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- reviews
DROP POLICY IF EXISTS reviews_isolation ON reviews;
CREATE POLICY reviews_isolation ON reviews
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- reports
DROP POLICY IF EXISTS content_reports_isolation ON content_reports;
CREATE POLICY content_reports_isolation ON content_reports
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- push notifications
DROP POLICY IF EXISTS push_notifications_isolation ON push_notifications;
CREATE POLICY push_notifications_isolation ON push_notifications
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- search_queries (append-like)
DROP POLICY IF EXISTS search_queries_isolation ON search_queries;
CREATE POLICY search_queries_isolation ON search_queries
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- metrics daily
DROP POLICY IF EXISTS business_metrics_daily_isolation ON business_metrics_daily;
CREATE POLICY business_metrics_daily_isolation ON business_metrics_daily
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- premium placements
DROP POLICY IF EXISTS premium_placements_isolation ON premium_placements;
CREATE POLICY premium_placements_isolation ON premium_placements
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
