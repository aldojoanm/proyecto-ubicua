-- Flyway V5: Business directory core (Parte B)
-- businesses, locations, hours, tags, services, contact channels

CREATE TABLE businesses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  name TEXT NOT NULL,
  legal_name TEXT NULL,
  type TEXT NOT NULL
    CHECK (type IN ('restaurant','bar','licoreria','tour','event_venue','other')),

  description_short TEXT NULL,
  description_long TEXT NULL,

  primary_phone TEXT NULL,
  whatsapp TEXT NULL,
  email CITEXT NULL,

  price_tier INT NULL CHECK (price_tier BETWEEN 1 AND 4),

  status TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','published','suspended')),

  metadata JSONB NULL,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID NULL,
  updated_at TIMESTAMPTZ NULL,
  updated_by UUID NULL,
  deleted_at TIMESTAMPTZ NULL,
  deleted_by UUID NULL,

  version BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX idx_businesses_tenant_status ON businesses(tenant_id, status);

CREATE TABLE business_locations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  label TEXT NOT NULL,
  address_line TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NULL,
  country_code CHAR(2) NOT NULL,

  geo GEOGRAPHY(Point,4326) NOT NULL,
  delivery_radius_km NUMERIC(6,2) NULL,

  is_primary BOOLEAN NOT NULL DEFAULT false,

  metadata JSONB NULL,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID NULL,
  updated_at TIMESTAMPTZ NULL,
  updated_by UUID NULL,
  deleted_at TIMESTAMPTZ NULL,
  deleted_by UUID NULL,

  version BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX idx_locations_tenant_business ON business_locations(tenant_id, business_id);
CREATE INDEX idx_locations_geo ON business_locations USING GIST (geo);

CREATE TABLE business_hours (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  location_id UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,

  day_of_week INT NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  open_time TIME NULL,
  close_time TIME NULL,
  is_closed BOOLEAN NOT NULL DEFAULT false,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID NULL,
  updated_at TIMESTAMPTZ NULL,
  updated_by UUID NULL,
  deleted_at TIMESTAMPTZ NULL,
  deleted_by UUID NULL,

  version BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_hours UNIQUE (tenant_id, location_id, day_of_week)
);

CREATE TABLE business_tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  name TEXT NOT NULL,
  kind TEXT NOT NULL
    CHECK (kind IN ('cuisine','ambience','service')),

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID NULL,

  version BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_tag UNIQUE (tenant_id, name, kind)
);

CREATE TABLE business_tag_links (
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  tag_id UUID NOT NULL REFERENCES business_tags(id) ON DELETE CASCADE,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID NULL,

  PRIMARY KEY (tenant_id, business_id, tag_id)
);

CREATE TABLE business_services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  service_type TEXT NOT NULL,
  is_enabled BOOLEAN NOT NULL DEFAULT true,
  meta_json JSONB NULL,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID NULL,
  updated_at TIMESTAMPTZ NULL,
  updated_by UUID NULL,

  version BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_business_service UNIQUE (tenant_id, business_id, service_type)
);

CREATE TABLE business_contact_channels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  channel TEXT NOT NULL,
  url TEXT NOT NULL,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID NULL,

  version BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_business_channel UNIQUE (tenant_id, business_id, channel)
);
