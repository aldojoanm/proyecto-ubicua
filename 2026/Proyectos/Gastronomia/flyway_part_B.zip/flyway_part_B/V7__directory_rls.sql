-- Flyway V7: RLS enable + baseline policies for Directory tables (Part B)
-- Uses app.current_tenant_id() from V4.

ALTER TABLE businesses                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_locations         ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_hours             ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_contact_channels  ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_tags              ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_tag_links         ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_services          ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_i18n              ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS businesses_isolation ON businesses;
CREATE POLICY businesses_isolation ON businesses
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS business_locations_isolation ON business_locations;
CREATE POLICY business_locations_isolation ON business_locations
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS business_hours_isolation ON business_hours;
CREATE POLICY business_hours_isolation ON business_hours
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS business_contact_channels_isolation ON business_contact_channels;
CREATE POLICY business_contact_channels_isolation ON business_contact_channels
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS business_tags_isolation ON business_tags;
CREATE POLICY business_tags_isolation ON business_tags
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS business_tag_links_isolation ON business_tag_links;
CREATE POLICY business_tag_links_isolation ON business_tag_links
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS business_services_isolation ON business_services;
CREATE POLICY business_services_isolation ON business_services
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS business_i18n_isolation ON business_i18n;
CREATE POLICY business_i18n_isolation ON business_i18n
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
