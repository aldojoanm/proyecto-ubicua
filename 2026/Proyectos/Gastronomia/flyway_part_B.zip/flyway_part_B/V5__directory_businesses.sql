-- Flyway V5: Directory (Part B) – Businesses, Locations, Hours, Contact Channels
-- Requires extensions from V1 (postgis, pgcrypto) and tenancy from V2.

CREATE TABLE IF NOT EXISTS businesses (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  name               TEXT NOT NULL,
  legal_name         TEXT NULL,

  -- restaurant | bar | licoreria | tour | event_venue | cafe | bakery | food_truck | other
  type               TEXT NOT NULL,
  price_tier         SMALLINT NULL CHECK (price_tier BETWEEN 1 AND 4),

  description_short  TEXT NULL,
  description_long   TEXT NULL,

  primary_phone      TEXT NULL,
  whatsapp           TEXT NULL,
  email              TEXT NULL,

  status             TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','published','suspended')),

  primary_location_id UUID NULL,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_businesses_tenant_status ON businesses(tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_businesses_tenant_type   ON businesses(tenant_id, type);
CREATE INDEX IF NOT EXISTS idx_businesses_tenant_name   ON businesses(tenant_id, name);

CREATE TABLE IF NOT EXISTS business_locations (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  label              TEXT NULL,
  address_line       TEXT NULL,
  city               TEXT NULL,
  state              TEXT NULL,
  country_code       CHAR(2) NULL,

  geo                GEOGRAPHY(Point, 4326) NOT NULL,
  delivery_radius_km NUMERIC(8,3) NULL CHECK (delivery_radius_km >= 0),

  is_primary         BOOLEAN NOT NULL DEFAULT false,
  is_active          BOOLEAN NOT NULL DEFAULT true,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_locations_tenant_business ON business_locations(tenant_id, business_id);
CREATE INDEX IF NOT EXISTS idx_locations_geo_gist ON business_locations USING GIST (geo);
CREATE INDEX IF NOT EXISTS idx_locations_primary ON business_locations(tenant_id, business_id, is_primary);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'fk_businesses_primary_location'
  ) THEN
    ALTER TABLE businesses
      ADD CONSTRAINT fk_businesses_primary_location
      FOREIGN KEY (primary_location_id)
      REFERENCES business_locations(id)
      DEFERRABLE INITIALLY DEFERRED;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS business_hours (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  location_id         UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,

  day_of_week         SMALLINT NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  open_time           TIME NULL,
  close_time          TIME NULL,
  is_closed           BOOLEAN NOT NULL DEFAULT false,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT ck_hours_open_close
    CHECK (
      (is_closed = true AND open_time IS NULL AND close_time IS NULL)
      OR
      (is_closed = false AND open_time IS NOT NULL AND close_time IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS idx_hours_tenant_location ON business_hours(tenant_id, location_id);

CREATE TABLE IF NOT EXISTS business_contact_channels (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  channel            TEXT NOT NULL
    CHECK (channel IN ('instagram','tiktok','facebook','web','whatsapp','phone','email','google_maps')),

  url                TEXT NOT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_business_channel UNIQUE (tenant_id, business_id, channel, url)
);

CREATE INDEX IF NOT EXISTS idx_channels_tenant_business ON business_contact_channels(tenant_id, business_id);
