-- Flyway V6: i18n tables for business entities (Parte B)

CREATE TABLE business_i18n (
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  lang TEXT NOT NULL, -- e.g. es, en, pt-BR
  name TEXT NOT NULL,
  description TEXT NULL,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID NULL,
  updated_at TIMESTAMPTZ NULL,
  updated_by UUID NULL,

  version BIGINT NOT NULL DEFAULT 0,

  PRIMARY KEY (tenant_id, business_id, lang)
);

CREATE TABLE business_service_i18n (
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_service_id UUID NOT NULL REFERENCES business_services(id) ON DELETE CASCADE,

  lang TEXT NOT NULL,
  label TEXT NOT NULL,
  description TEXT NULL,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID NULL,

  version BIGINT NOT NULL DEFAULT 0,

  PRIMARY KEY (tenant_id, business_service_id, lang)
);
