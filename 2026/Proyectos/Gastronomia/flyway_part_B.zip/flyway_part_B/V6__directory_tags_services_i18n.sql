-- Flyway V6: Directory (Part B) – Tags, Services, i18n
-- Supports advanced search filters and multi-language content.

CREATE TABLE IF NOT EXISTS business_tags (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  name               TEXT NOT NULL,
  kind               TEXT NOT NULL
    CHECK (kind IN ('cuisine','ambience','service','music','occasion','other')),

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_business_tags UNIQUE (tenant_id, kind, name)
);

CREATE INDEX IF NOT EXISTS idx_tags_tenant_kind ON business_tags(tenant_id, kind);

CREATE TABLE IF NOT EXISTS business_tag_links (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  tag_id              UUID NOT NULL REFERENCES business_tags(id) ON DELETE CASCADE,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  PRIMARY KEY (tenant_id, business_id, tag_id)
);

CREATE INDEX IF NOT EXISTS idx_tag_links_tag ON business_tag_links(tenant_id, tag_id);

CREATE TABLE IF NOT EXISTS business_services (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  service_type       TEXT NOT NULL,
  is_enabled         BOOLEAN NOT NULL DEFAULT true,

  meta_json          JSONB NOT NULL DEFAULT '{}'::jsonb,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_business_service UNIQUE (tenant_id, business_id, service_type)
);

CREATE INDEX IF NOT EXISTS idx_services_tenant_business ON business_services(tenant_id, business_id);

CREATE TABLE IF NOT EXISTS business_i18n (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  lang               TEXT NOT NULL,

  name               TEXT NOT NULL,
  description_short  TEXT NULL,
  description_long   TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_business_i18n UNIQUE (tenant_id, business_id, lang)
);

CREATE INDEX IF NOT EXISTS idx_business_i18n_lang ON business_i18n(tenant_id, lang);
