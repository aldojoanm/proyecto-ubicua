-- Flyway V18: Part F – Orders, Order Items, KDS, Payments, Cash
-- Depends on: V17 reservations/areas/tables, V5 business_locations, V8-10 menu tables

-- -------------------------------------------------------------------
-- orders
-- business_id is redundant but speeds up queries and aligns with other domains.
-- status follows the "kitchen pipeline" pattern.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  location_id         UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,

  table_id            UUID NULL REFERENCES dining_tables(id) ON DELETE SET NULL,
  reservation_id      UUID NULL REFERENCES reservations(id) ON DELETE SET NULL,

  opened_by_user_id   UUID NULL, -- IAM user
  waiter_user_id      UUID NULL, -- IAM user (optional)

  order_type          TEXT NOT NULL DEFAULT 'dine_in'
    CHECK (order_type IN ('dine_in','takeaway','delivery')),

  status              TEXT NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','sent_to_kitchen','preparing','ready','served','closed','cancelled')),

  currency_code       CHAR(3) NOT NULL,

  subtotal_amount     NUMERIC(19,4) NOT NULL DEFAULT 0,
  tax_amount          NUMERIC(19,4) NOT NULL DEFAULT 0,
  discount_amount     NUMERIC(19,4) NOT NULL DEFAULT 0,
  total_amount        NUMERIC(19,4) NOT NULL DEFAULT 0,

  notes               TEXT NULL,
  metadata            JSONB NULL,

  opened_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at           TIMESTAMPTZ NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,
  updated_at          TIMESTAMPTZ NULL,
  updated_by          UUID NULL,
  deleted_at          TIMESTAMPTZ NULL,
  deleted_by          UUID NULL,

  version             BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_orders_tenant_location_status_time
  ON orders(tenant_id, location_id, status, opened_at DESC);

CREATE INDEX IF NOT EXISTS idx_orders_tenant_business_time
  ON orders(tenant_id, business_id, opened_at DESC);

CREATE INDEX IF NOT EXISTS idx_orders_tenant_table_status
  ON orders(tenant_id, table_id, status);

-- -------------------------------------------------------------------
-- order_items
-- Price snapshots are stored to keep historical accuracy even if menu changes later.
-- menu_item_variant_id optional.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  order_id            UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,

  menu_item_id        UUID NULL REFERENCES menu_items(id) ON DELETE SET NULL,
  menu_item_variant_id UUID NULL REFERENCES menu_item_variants(id) ON DELETE SET NULL,

  name_snapshot       TEXT NOT NULL,
  unit_price_snapshot NUMERIC(19,4) NOT NULL DEFAULT 0,
  currency_code       CHAR(3) NOT NULL,

  quantity            NUMERIC(19,4) NOT NULL DEFAULT 1 CHECK (quantity > 0),
  notes               TEXT NULL,

  status              TEXT NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued','preparing','ready','served','cancelled')),

  kitchen_station     TEXT NULL, -- optional (grill/bar/pizza)
  metadata            JSONB NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,
  updated_at          TIMESTAMPTZ NULL,
  updated_by          UUID NULL,

  version             BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_order_items_tenant_order_status
  ON order_items(tenant_id, order_id, status);

-- -------------------------------------------------------------------
-- kitchen_tickets: grouping of items for KDS
-- One order can have multiple tickets (split by station).
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS kitchen_tickets (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  order_id            UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,

  station            TEXT NULL,
  status             TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','in_progress','done','cancelled')),

  priority           SMALLINT NOT NULL DEFAULT 2 CHECK (priority BETWEEN 1 AND 5),

  started_at         TIMESTAMPTZ NULL,
  completed_at       TIMESTAMPTZ NULL,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_kitchen_tickets_tenant_station_status
  ON kitchen_tickets(tenant_id, station, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_kitchen_tickets_tenant_order
  ON kitchen_tickets(tenant_id, order_id);

-- -------------------------------------------------------------------
-- kitchen_ticket_items: items inside each ticket (subset of order_items)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS kitchen_ticket_items (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  ticket_id           UUID NOT NULL REFERENCES kitchen_tickets(id) ON DELETE CASCADE,
  order_item_id       UUID NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,

  PRIMARY KEY (tenant_id, ticket_id, order_item_id)
);

CREATE INDEX IF NOT EXISTS idx_kitchen_ticket_items_ticket
  ON kitchen_ticket_items(tenant_id, ticket_id);

-- -------------------------------------------------------------------
-- payments: supports cash/card/qr/transfer
-- Keep provider_ref and idempotency_key for safe retries
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  order_id            UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,

  method             TEXT NOT NULL
    CHECK (method IN ('cash','card','qr','transfer','wallet')),

  status             TEXT NOT NULL DEFAULT 'authorized'
    CHECK (status IN ('authorized','paid','void','refunded','failed')),

  amount             NUMERIC(19,4) NOT NULL CHECK (amount >= 0),
  currency_code      CHAR(3) NOT NULL,

  provider           TEXT NULL, -- e.g. "stripe", "mercadopago", "local_qr"
  provider_ref       TEXT NULL,
  idempotency_key    TEXT NULL,

  paid_at            TIMESTAMPTZ NULL,
  failure_reason     TEXT NULL,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_payments_tenant_order
  ON payments(tenant_id, order_id);

CREATE INDEX IF NOT EXISTS idx_payments_tenant_status_time
  ON payments(tenant_id, status, created_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS uq_payments_idempotency
  ON payments(tenant_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

-- -------------------------------------------------------------------
-- cash_registers
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cash_registers (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  location_id         UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,
  name               TEXT NOT NULL,
  is_active          BOOLEAN NOT NULL DEFAULT true,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_cash_register_name UNIQUE (tenant_id, location_id, name)
);

CREATE INDEX IF NOT EXISTS idx_cash_registers_tenant_location
  ON cash_registers(tenant_id, location_id);

-- -------------------------------------------------------------------
-- cash_sessions: daily opens/closes
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cash_sessions (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  register_id         UUID NOT NULL REFERENCES cash_registers(id) ON DELETE CASCADE,

  opened_by_user_id   UUID NOT NULL,
  opened_at           TIMESTAMPTZ NOT NULL DEFAULT now(),

  closed_by_user_id   UUID NULL,
  closed_at           TIMESTAMPTZ NULL,

  opening_amount      NUMERIC(19,4) NOT NULL DEFAULT 0,
  closing_amount      NUMERIC(19,4) NULL,

  currency_code       CHAR(3) NOT NULL,

  status              TEXT NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','closed')),

  metadata            JSONB NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,
  updated_at          TIMESTAMPTZ NULL,
  updated_by          UUID NULL,

  version             BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_cash_sessions_tenant_register_status
  ON cash_sessions(tenant_id, register_id, status, opened_at DESC);

-- -------------------------------------------------------------------
-- cash_session_movements: cash in/out (expenses, withdrawals, tips, etc.)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cash_session_movements (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  session_id          UUID NOT NULL REFERENCES cash_sessions(id) ON DELETE CASCADE,

  movement_type       TEXT NOT NULL
    CHECK (movement_type IN ('cash_in','cash_out','expense','withdrawal','tip_in','tip_out','adjustment')),

  amount              NUMERIC(19,4) NOT NULL,
  currency_code       CHAR(3) NOT NULL,

  reason              TEXT NULL,
  reference_type      TEXT NULL,
  reference_id        UUID NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,

  version             BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_cash_movements_tenant_session_time
  ON cash_session_movements(tenant_id, session_id, created_at DESC);
