-- Flyway V19: Part F – RLS enable + baseline tenant policies
-- Uses app.current_tenant_id() from V4.

ALTER TABLE dining_areas              ENABLE ROW LEVEL SECURITY;
ALTER TABLE dining_tables             ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservations              ENABLE ROW LEVEL SECURITY;

ALTER TABLE orders                    ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items               ENABLE ROW LEVEL SECURITY;
ALTER TABLE kitchen_tickets           ENABLE ROW LEVEL SECURITY;
ALTER TABLE kitchen_ticket_items      ENABLE ROW LEVEL SECURITY;

ALTER TABLE payments                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE cash_registers            ENABLE ROW LEVEL SECURITY;
ALTER TABLE cash_sessions             ENABLE ROW LEVEL SECURITY;
ALTER TABLE cash_session_movements    ENABLE ROW LEVEL SECURITY;

-- dining_areas
DROP POLICY IF EXISTS dining_areas_isolation ON dining_areas;
CREATE POLICY dining_areas_isolation ON dining_areas
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- dining_tables
DROP POLICY IF EXISTS dining_tables_isolation ON dining_tables;
CREATE POLICY dining_tables_isolation ON dining_tables
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- reservations
DROP POLICY IF EXISTS reservations_isolation ON reservations;
CREATE POLICY reservations_isolation ON reservations
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- orders
DROP POLICY IF EXISTS orders_isolation ON orders;
CREATE POLICY orders_isolation ON orders
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- order_items
DROP POLICY IF EXISTS order_items_isolation ON order_items;
CREATE POLICY order_items_isolation ON order_items
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- kitchen_tickets
DROP POLICY IF EXISTS kitchen_tickets_isolation ON kitchen_tickets;
CREATE POLICY kitchen_tickets_isolation ON kitchen_tickets
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- kitchen_ticket_items
DROP POLICY IF EXISTS kitchen_ticket_items_isolation ON kitchen_ticket_items;
CREATE POLICY kitchen_ticket_items_isolation ON kitchen_ticket_items
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- payments
DROP POLICY IF EXISTS payments_isolation ON payments;
CREATE POLICY payments_isolation ON payments
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- cash_registers
DROP POLICY IF EXISTS cash_registers_isolation ON cash_registers;
CREATE POLICY cash_registers_isolation ON cash_registers
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- cash_sessions
DROP POLICY IF EXISTS cash_sessions_isolation ON cash_sessions;
CREATE POLICY cash_sessions_isolation ON cash_sessions
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- cash_session_movements
DROP POLICY IF EXISTS cash_session_movements_isolation ON cash_session_movements;
CREATE POLICY cash_session_movements_isolation ON cash_session_movements
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
