-- Flyway V17: Part F – Restaurant Ops (Core): Areas, Tables, Reservations
-- Depends on: V2 tenants, V5 business_locations, V4 app schema for RLS

-- -------------------------------------------------------------------
-- dining_areas: physical zones within a location (e.g., "Patio", "Salón")
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dining_areas (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  location_id         UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,

  name               TEXT NOT NULL,
  sort_order         INT NOT NULL DEFAULT 0,
  is_active          BOOLEAN NOT NULL DEFAULT true,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_area_name UNIQUE (tenant_id, location_id, name)
);

CREATE INDEX IF NOT EXISTS idx_areas_tenant_location
  ON dining_areas(tenant_id, location_id);

-- -------------------------------------------------------------------
-- dining_tables: avoid reserved keyword "tables"
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dining_tables (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  area_id             UUID NOT NULL REFERENCES dining_areas(id) ON DELETE CASCADE,

  label              TEXT NOT NULL, -- e.g. "Mesa 1"
  capacity           INT NULL CHECK (capacity IS NULL OR capacity >= 0),

  status             TEXT NOT NULL DEFAULT 'free'
    CHECK (status IN ('free','reserved','occupied','disabled')),

  qr_code            TEXT NULL, -- optional: table QR token/id (not secret)
  is_active          BOOLEAN NOT NULL DEFAULT true,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_table_label UNIQUE (tenant_id, area_id, label)
);

CREATE INDEX IF NOT EXISTS idx_tables_tenant_area_status
  ON dining_tables(tenant_id, area_id, status);

-- -------------------------------------------------------------------
-- reservations
-- If table_id is NULL, reservation is waitlist / not yet assigned.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reservations (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  location_id         UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,
  table_id            UUID NULL REFERENCES dining_tables(id) ON DELETE SET NULL,

  customer_name      TEXT NOT NULL,
  customer_phone     TEXT NULL,
  customer_email     TEXT NULL,

  party_size         INT NOT NULL CHECK (party_size > 0),
  reserved_at        TIMESTAMPTZ NOT NULL,

  status             TEXT NOT NULL DEFAULT 'requested'
    CHECK (status IN ('requested','confirmed','cancelled','no_show','seated','completed')),

  source             TEXT NOT NULL DEFAULT 'manual'
    CHECK (source IN ('manual','online','phone','walk_in')),

  notes              TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_reservations_tenant_location_time
  ON reservations(tenant_id, location_id, reserved_at);

CREATE INDEX IF NOT EXISTS idx_reservations_tenant_status_time
  ON reservations(tenant_id, status, reserved_at);

CREATE INDEX IF NOT EXISTS idx_reservations_tenant_table_time
  ON reservations(tenant_id, table_id, reserved_at);
