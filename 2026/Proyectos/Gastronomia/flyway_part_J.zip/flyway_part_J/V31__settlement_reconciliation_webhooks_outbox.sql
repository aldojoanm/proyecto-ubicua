-- Flyway V31: Part J – Reconciliation + Provider Webhooks + Outbox glue
-- Depends on: V30 payout_transfers, V25 outbox_events

CREATE TABLE IF NOT EXISTS provider_webhook_events (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  provider            TEXT NOT NULL,
  event_type          TEXT NOT NULL,
  provider_event_id   TEXT NULL,

  received_at         TIMESTAMPTZ NOT NULL DEFAULT now(),

  signature_ok        BOOLEAN NOT NULL DEFAULT false,

  payload_json        JSONB NOT NULL,

  processed_status    TEXT NOT NULL DEFAULT 'new'
    CHECK (processed_status IN ('new','processed','failed','ignored')),

  processed_at        TIMESTAMPTZ NULL,
  error_message       TEXT NULL
);

CREATE INDEX IF NOT EXISTS idx_webhooks_tenant_provider_time
  ON provider_webhook_events(tenant_id, provider, received_at DESC);

CREATE INDEX IF NOT EXISTS idx_webhooks_tenant_status_time
  ON provider_webhook_events(tenant_id, processed_status, received_at DESC);

CREATE TABLE IF NOT EXISTS reconciliation_records (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  provider            TEXT NOT NULL,
  statement_date      DATE NOT NULL,

  provider_ref        TEXT NULL,
  internal_transfer_id UUID NULL REFERENCES payout_transfers(id) ON DELETE SET NULL,

  amount              NUMERIC(19,4) NOT NULL,
  currency_code       CHAR(3) NOT NULL,

  status              TEXT NOT NULL DEFAULT 'unmatched'
    CHECK (status IN ('unmatched','matched','mismatch','ignored')),

  mismatch_reason     TEXT NULL,

  raw_json            JSONB NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,

  version             BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_recon_tenant_provider_date
  ON reconciliation_records(tenant_id, provider, statement_date DESC);

CREATE INDEX IF NOT EXISTS idx_recon_tenant_status
  ON reconciliation_records(tenant_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS payout_outbox_links (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  outbox_event_id     UUID NOT NULL REFERENCES outbox_events(id) ON DELETE CASCADE,
  transfer_id         UUID NULL REFERENCES payout_transfers(id) ON DELETE SET NULL,
  payout_id           UUID NULL REFERENCES payout_requests(id) ON DELETE SET NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

  version             BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_payout_outbox_links_tenant_event
  ON payout_outbox_links(tenant_id, outbox_event_id);
