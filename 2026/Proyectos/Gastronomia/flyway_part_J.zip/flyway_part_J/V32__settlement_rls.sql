-- Flyway V32: Part J – RLS policies for settlement/payout engine tables
-- Uses app.current_tenant_id() from V4.

ALTER TABLE settlement_runs            ENABLE ROW LEVEL SECURITY;
ALTER TABLE payout_batches             ENABLE ROW LEVEL SECURITY;
ALTER TABLE payout_batch_items         ENABLE ROW LEVEL SECURITY;
ALTER TABLE payout_withholdings        ENABLE ROW LEVEL SECURITY;
ALTER TABLE payout_transfers           ENABLE ROW LEVEL SECURITY;
ALTER TABLE settlement_adjustments     ENABLE ROW LEVEL SECURITY;

ALTER TABLE provider_webhook_events    ENABLE ROW LEVEL SECURITY;
ALTER TABLE reconciliation_records     ENABLE ROW LEVEL SECURITY;
ALTER TABLE payout_outbox_links        ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS settlement_runs_isolation ON settlement_runs;
CREATE POLICY settlement_runs_isolation ON settlement_runs
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS payout_batches_isolation ON payout_batches;
CREATE POLICY payout_batches_isolation ON payout_batches
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS payout_batch_items_isolation ON payout_batch_items;
CREATE POLICY payout_batch_items_isolation ON payout_batch_items
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS payout_withholdings_isolation ON payout_withholdings;
CREATE POLICY payout_withholdings_isolation ON payout_withholdings
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS payout_transfers_isolation ON payout_transfers;
CREATE POLICY payout_transfers_isolation ON payout_transfers
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS settlement_adjustments_isolation ON settlement_adjustments;
CREATE POLICY settlement_adjustments_isolation ON settlement_adjustments
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS provider_webhook_events_isolation ON provider_webhook_events;
CREATE POLICY provider_webhook_events_isolation ON provider_webhook_events
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS reconciliation_records_isolation ON reconciliation_records;
CREATE POLICY reconciliation_records_isolation ON reconciliation_records
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS payout_outbox_links_isolation ON payout_outbox_links;
CREATE POLICY payout_outbox_links_isolation ON payout_outbox_links
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
