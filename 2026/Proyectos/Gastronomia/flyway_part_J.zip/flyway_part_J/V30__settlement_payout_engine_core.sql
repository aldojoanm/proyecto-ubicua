-- Flyway V30: Part J – Settlement & Payout Engine (Enterprise-grade)
-- Weekly (or configurable) closings, payout batches, withholdings, reversals.
-- Depends on: V28 payout_requests, commission_ledger, partner_balances; V25 outbox_events/idempotency_keys (optional)

CREATE TABLE IF NOT EXISTS settlement_runs (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  project_id          UUID NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,

  period_start       TIMESTAMPTZ NOT NULL,
  period_end         TIMESTAMPTZ NOT NULL,

  status             TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','running','completed','failed','void')),

  rules_snapshot_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  metrics_json        JSONB NULL,

  started_at         TIMESTAMPTZ NULL,
  completed_at       TIMESTAMPTZ NULL,

  error_message      TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT ck_settlement_period CHECK (period_start < period_end)
);

CREATE INDEX IF NOT EXISTS idx_settlement_runs_tenant_project_period
  ON settlement_runs(tenant_id, project_id, period_start DESC);

CREATE INDEX IF NOT EXISTS idx_settlement_runs_tenant_status
  ON settlement_runs(tenant_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS payout_batches (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  project_id          UUID NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,
  settlement_run_id   UUID NULL REFERENCES settlement_runs(id) ON DELETE SET NULL,

  batch_code          TEXT NOT NULL,
  status              TEXT NOT NULL DEFAULT 'created'
    CHECK (status IN ('created','submitted','partially_paid','paid','failed','void')),

  method              TEXT NOT NULL DEFAULT 'mixed'
    CHECK (method IN ('mixed','bank','qr','transfer','wallet')),

  currency_code       CHAR(3) NOT NULL,

  total_amount        NUMERIC(19,4) NOT NULL DEFAULT 0,
  total_count         INT NOT NULL DEFAULT 0,

  submitted_at        TIMESTAMPTZ NULL,
  completed_at        TIMESTAMPTZ NULL,

  provider            TEXT NULL,
  provider_batch_ref  TEXT NULL,

  metadata            JSONB NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,
  updated_at          TIMESTAMPTZ NULL,
  updated_by          UUID NULL,

  version             BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_payout_batch_code UNIQUE (tenant_id, batch_code)
);

CREATE INDEX IF NOT EXISTS idx_payout_batches_tenant_project_status
  ON payout_batches(tenant_id, project_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS payout_batch_items (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  batch_id            UUID NOT NULL REFERENCES payout_batches(id) ON DELETE CASCADE,
  payout_id           UUID NOT NULL REFERENCES payout_requests(id) ON DELETE RESTRICT,

  amount              NUMERIC(19,4) NOT NULL,
  currency_code       CHAR(3) NOT NULL,

  status              TEXT NOT NULL DEFAULT 'included'
    CHECK (status IN ('included','submitted','paid','failed','void')),

  provider_ref        TEXT NULL,
  processed_at        TIMESTAMPTZ NULL,
  failure_reason      TEXT NULL,

  PRIMARY KEY (tenant_id, batch_id, payout_id)
);

CREATE INDEX IF NOT EXISTS idx_payout_batch_items_batch
  ON payout_batch_items(tenant_id, batch_id);

CREATE INDEX IF NOT EXISTS idx_payout_batch_items_payout
  ON payout_batch_items(tenant_id, payout_id);

CREATE TABLE IF NOT EXISTS payout_withholdings (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  payout_id           UUID NOT NULL REFERENCES payout_requests(id) ON DELETE CASCADE,

  withholding_type   TEXT NOT NULL,
  rate               NUMERIC(10,6) NULL,
  amount             NUMERIC(19,4) NOT NULL DEFAULT 0,
  currency_code      CHAR(3) NOT NULL,

  legal_basis        TEXT NULL,
  notes              TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_withholdings_tenant_payout
  ON payout_withholdings(tenant_id, payout_id);

CREATE TABLE IF NOT EXISTS payout_transfers (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  batch_id            UUID NULL REFERENCES payout_batches(id) ON DELETE SET NULL,
  payout_id           UUID NOT NULL REFERENCES payout_requests(id) ON DELETE RESTRICT,

  provider            TEXT NOT NULL,
  idempotency_key    TEXT NOT NULL,
  provider_ref       TEXT NULL,

  status              TEXT NOT NULL DEFAULT 'created'
    CHECK (status IN ('created','submitted','paid','failed','void')),

  amount              NUMERIC(19,4) NOT NULL,
  currency_code       CHAR(3) NOT NULL,

  submitted_at        TIMESTAMPTZ NULL,
  paid_at             TIMESTAMPTZ NULL,
  failed_at           TIMESTAMPTZ NULL,
  failure_reason      TEXT NULL,

  request_json        JSONB NULL,
  response_json       JSONB NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,
  updated_at          TIMESTAMPTZ NULL,
  updated_by          UUID NULL,

  version             BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_payout_transfer_idemp UNIQUE (tenant_id, provider, idempotency_key)
);

CREATE INDEX IF NOT EXISTS idx_payout_transfers_tenant_status_time
  ON payout_transfers(tenant_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_payout_transfers_tenant_payout
  ON payout_transfers(tenant_id, payout_id);

CREATE TABLE IF NOT EXISTS settlement_adjustments (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  project_id          UUID NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,
  partner_project_id  UUID NOT NULL REFERENCES partner_projects(id) ON DELETE RESTRICT,

  adjustment_type    TEXT NOT NULL
    CHECK (adjustment_type IN ('chargeback','reversal','penalty','bonus','manual_correction','fee')),

  amount              NUMERIC(19,4) NOT NULL,
  currency_code       CHAR(3) NOT NULL,

  reference_type      TEXT NULL,
  reference_id        UUID NULL,

  status              TEXT NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','applied','void')),

  note                TEXT NULL,
  metadata            JSONB NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,
  applied_at          TIMESTAMPTZ NULL,
  applied_by          UUID NULL,

  version             BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_settlement_adj_tenant_partner_status
  ON settlement_adjustments(tenant_id, partner_project_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_settlement_adj_tenant_project_time
  ON settlement_adjustments(tenant_id, project_id, created_at DESC);
