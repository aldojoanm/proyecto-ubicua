-- Flyway V35: Part K – RLS policies for Accounting/Tax/Reporting tables
-- Uses app.current_tenant_id() from V4.

ALTER TABLE fiscal_periods        ENABLE ROW LEVEL SECURITY;
ALTER TABLE chart_of_accounts     ENABLE ROW LEVEL SECURITY;
ALTER TABLE fx_rates              ENABLE ROW LEVEL SECURITY;
ALTER TABLE gl_journal_entries    ENABLE ROW LEVEL SECURITY;
ALTER TABLE gl_journal_lines      ENABLE ROW LEVEL SECURITY;
ALTER TABLE gl_posting_errors     ENABLE ROW LEVEL SECURITY;

ALTER TABLE tax_profiles          ENABLE ROW LEVEL SECURITY;
ALTER TABLE tax_rates             ENABLE ROW LEVEL SECURITY;
ALTER TABLE tax_rules             ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_taxes         ENABLE ROW LEVEL SECURITY;
ALTER TABLE payout_tax_reports    ENABLE ROW LEVEL SECURITY;

ALTER TABLE report_templates      ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_exports        ENABLE ROW LEVEL SECURITY;

-- fiscal_periods
DROP POLICY IF EXISTS fiscal_periods_isolation ON fiscal_periods;
CREATE POLICY fiscal_periods_isolation ON fiscal_periods
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- chart_of_accounts
DROP POLICY IF EXISTS chart_of_accounts_isolation ON chart_of_accounts;
CREATE POLICY chart_of_accounts_isolation ON chart_of_accounts
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- fx_rates
DROP POLICY IF EXISTS fx_rates_isolation ON fx_rates;
CREATE POLICY fx_rates_isolation ON fx_rates
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- gl_journal_entries
DROP POLICY IF EXISTS gl_journal_entries_isolation ON gl_journal_entries;
CREATE POLICY gl_journal_entries_isolation ON gl_journal_entries
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- gl_journal_lines
DROP POLICY IF EXISTS gl_journal_lines_isolation ON gl_journal_lines;
CREATE POLICY gl_journal_lines_isolation ON gl_journal_lines
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- gl_posting_errors
DROP POLICY IF EXISTS gl_posting_errors_isolation ON gl_posting_errors;
CREATE POLICY gl_posting_errors_isolation ON gl_posting_errors
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- tax_profiles
DROP POLICY IF EXISTS tax_profiles_isolation ON tax_profiles;
CREATE POLICY tax_profiles_isolation ON tax_profiles
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- tax_rates
DROP POLICY IF EXISTS tax_rates_isolation ON tax_rates;
CREATE POLICY tax_rates_isolation ON tax_rates
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- tax_rules
DROP POLICY IF EXISTS tax_rules_isolation ON tax_rules;
CREATE POLICY tax_rules_isolation ON tax_rules
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- invoice_taxes
DROP POLICY IF EXISTS invoice_taxes_isolation ON invoice_taxes;
CREATE POLICY invoice_taxes_isolation ON invoice_taxes
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- payout_tax_reports
DROP POLICY IF EXISTS payout_tax_reports_isolation ON payout_tax_reports;
CREATE POLICY payout_tax_reports_isolation ON payout_tax_reports
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- report_templates
DROP POLICY IF EXISTS report_templates_isolation ON report_templates;
CREATE POLICY report_templates_isolation ON report_templates
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- report_exports
DROP POLICY IF EXISTS report_exports_isolation ON report_exports;
CREATE POLICY report_exports_isolation ON report_exports
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
