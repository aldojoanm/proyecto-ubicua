-- Flyway V33: Part K – Accounting / General Ledger (GL) Core
-- Purpose: enterprise-grade bookkeeping foundations for SaaS billing, restaurant ops, payouts.
-- Depends on: V2 tenants, V24 invoices, V18 orders/payments, V30 payouts/transfers (if used)

-- -------------------------------------------------------------------
-- fiscal_periods: accounting periods (monthly/quarterly) per tenant
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fiscal_periods (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  code               TEXT NOT NULL, -- e.g. 2026-01
  period_start       DATE NOT NULL,
  period_end         DATE NOT NULL,

  status             TEXT NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','closed','locked')),

  closed_at          TIMESTAMPTZ NULL,
  closed_by          UUID NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_fiscal_period UNIQUE (tenant_id, code),
  CONSTRAINT ck_fiscal_period_dates CHECK (period_start <= period_end)
);

CREATE INDEX IF NOT EXISTS idx_fiscal_periods_tenant_status
  ON fiscal_periods(tenant_id, status, period_start DESC);

-- -------------------------------------------------------------------
-- chart_of_accounts: COA per tenant (can be templated per country)
-- account_type: asset, liability, equity, revenue, expense
-- normal_balance: debit/credit
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS chart_of_accounts (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  code               TEXT NOT NULL, -- e.g. 1.1.01
  name               TEXT NOT NULL,

  account_type       TEXT NOT NULL
    CHECK (account_type IN ('asset','liability','equity','revenue','expense')),

  normal_balance     TEXT NOT NULL
    CHECK (normal_balance IN ('debit','credit')),

  parent_id          UUID NULL REFERENCES chart_of_accounts(id) ON DELETE SET NULL,

  is_active          BOOLEAN NOT NULL DEFAULT true,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_coa_code UNIQUE (tenant_id, code)
);

CREATE INDEX IF NOT EXISTS idx_coa_tenant_parent
  ON chart_of_accounts(tenant_id, parent_id);

CREATE INDEX IF NOT EXISTS idx_coa_tenant_type
  ON chart_of_accounts(tenant_id, account_type);

-- -------------------------------------------------------------------
-- fx_rates: FX rates for multi-currency consolidation
-- base_currency should match tenant.currency_code, but allow overrides.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fx_rates (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  rate_date          DATE NOT NULL,
  base_currency      CHAR(3) NOT NULL,
  quote_currency     CHAR(3) NOT NULL,

  rate               NUMERIC(19,8) NOT NULL CHECK (rate > 0),

  provider           TEXT NULL, -- e.g. "manual", "coingecko", "central_bank"
  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_fx_rate UNIQUE (tenant_id, rate_date, base_currency, quote_currency),
  CONSTRAINT ck_fx_currency CHECK (base_currency <> quote_currency)
);

CREATE INDEX IF NOT EXISTS idx_fx_rates_tenant_date
  ON fx_rates(tenant_id, rate_date DESC);

-- -------------------------------------------------------------------
-- gl_journal_entries: double-entry journals (header)
-- source_type examples: invoice, payment, order, payout, adjustment, manual
-- status: draft/posted/void
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gl_journal_entries (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  fiscal_period_id    UUID NULL REFERENCES fiscal_periods(id) ON DELETE SET NULL,

  entry_date         DATE NOT NULL DEFAULT (now()::date),
  description        TEXT NULL,

  source_type        TEXT NOT NULL DEFAULT 'manual',
  source_id          UUID NULL,

  status             TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','posted','void')),

  posted_at          TIMESTAMPTZ NULL,
  posted_by          UUID NULL,

  currency_code      CHAR(3) NOT NULL, -- transaction currency
  base_currency      CHAR(3) NOT NULL, -- tenant/base currency

  fx_rate            NUMERIC(19,8) NULL,
  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_gl_entries_tenant_date
  ON gl_journal_entries(tenant_id, entry_date DESC);

CREATE INDEX IF NOT EXISTS idx_gl_entries_tenant_status
  ON gl_journal_entries(tenant_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_gl_entries_source
  ON gl_journal_entries(tenant_id, source_type, source_id);

-- -------------------------------------------------------------------
-- gl_journal_lines: debit/credit lines
-- base_amount supports consolidation in base currency.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gl_journal_lines (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  journal_entry_id    UUID NOT NULL REFERENCES gl_journal_entries(id) ON DELETE CASCADE,

  account_id          UUID NOT NULL REFERENCES chart_of_accounts(id) ON DELETE RESTRICT,

  line_no            INT NOT NULL DEFAULT 1 CHECK (line_no > 0),

  dc                 TEXT NOT NULL CHECK (dc IN ('debit','credit')),

  amount             NUMERIC(19,4) NOT NULL CHECK (amount >= 0),
  currency_code      CHAR(3) NOT NULL,

  base_amount        NUMERIC(19,4) NULL,
  base_currency      CHAR(3) NOT NULL,

  memo               TEXT NULL,
  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_gl_lines_tenant_entry
  ON gl_journal_lines(tenant_id, journal_entry_id);

CREATE INDEX IF NOT EXISTS idx_gl_lines_tenant_account_date
  ON gl_journal_lines(tenant_id, account_id);

-- -------------------------------------------------------------------
-- gl_posting_errors: append-only errors for posting automation
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gl_posting_errors (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  source_type        TEXT NOT NULL,
  source_id          UUID NULL,

  error_message      TEXT NOT NULL,
  details_json       JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL
);

CREATE INDEX IF NOT EXISTS idx_gl_posting_errors_tenant_time
  ON gl_posting_errors(tenant_id, created_at DESC);
