-- Flyway V34: Part K – Taxes, Withholding Profiles, Reporting + Exports
-- Depends on: V24 invoices, V30 payout_requests (optional), V33 accounting core

-- -------------------------------------------------------------------
-- tax_profiles: per tenant configuration (country, regime, ids)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tax_profiles (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  country_code       CHAR(2) NOT NULL,
  regime             TEXT NULL, -- e.g. "general", "simplified"

  taxpayer_id        TEXT NULL, -- NIT/CUIT/RUC etc.
  legal_name         TEXT NULL,

  address_json       JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_tax_profile UNIQUE (tenant_id)
);

-- -------------------------------------------------------------------
-- tax_rates: named rates with validity (VAT, service tax, etc.)
-- rate 0..1
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tax_rates (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  code               TEXT NOT NULL, -- e.g. VAT_13
  name               TEXT NOT NULL,

  rate               NUMERIC(10,6) NOT NULL CHECK (rate >= 0 AND rate <= 1),

  effective_from     DATE NOT NULL,
  effective_to       DATE NULL,

  is_active          BOOLEAN NOT NULL DEFAULT true,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_tax_rate UNIQUE (tenant_id, code),
  CONSTRAINT ck_tax_rate_dates CHECK (effective_to IS NULL OR effective_from <= effective_to)
);

CREATE INDEX IF NOT EXISTS idx_tax_rates_tenant_time
  ON tax_rates(tenant_id, effective_from DESC);

-- -------------------------------------------------------------------
-- tax_rules: map what taxes apply to what source in the platform
-- source_type: invoice_item, order_item, subscription, payout
-- selector_json: flexible selector for categories, business types, etc.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tax_rules (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  source_type        TEXT NOT NULL
    CHECK (source_type IN ('invoice_item','order_item','subscription','payout')),

  tax_rate_id        UUID NOT NULL REFERENCES tax_rates(id) ON DELETE RESTRICT,

  selector_json      JSONB NOT NULL DEFAULT '{}'::jsonb,

  priority           INT NOT NULL DEFAULT 100,
  is_active          BOOLEAN NOT NULL DEFAULT true,

  effective_from     DATE NOT NULL,
  effective_to       DATE NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT ck_tax_rules_dates CHECK (effective_to IS NULL OR effective_from <= effective_to)
);

CREATE INDEX IF NOT EXISTS idx_tax_rules_tenant_source
  ON tax_rules(tenant_id, source_type, is_active, priority);

-- -------------------------------------------------------------------
-- invoice_taxes: computed taxes per invoice (snapshot for audit)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS invoice_taxes (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  invoice_id          UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,

  tax_rate_id        UUID NOT NULL REFERENCES tax_rates(id) ON DELETE RESTRICT,

  taxable_amount     NUMERIC(19,4) NOT NULL DEFAULT 0,
  tax_amount         NUMERIC(19,4) NOT NULL DEFAULT 0,
  currency_code      CHAR(3) NOT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_invoice_taxes_tenant_invoice
  ON invoice_taxes(tenant_id, invoice_id);

-- -------------------------------------------------------------------
-- payout_tax_reports: tax snapshots for partner payouts (optional)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payout_tax_reports (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  payout_id           UUID NOT NULL REFERENCES payout_requests(id) ON DELETE CASCADE,

  country_code       CHAR(2) NULL,
  taxable_amount     NUMERIC(19,4) NOT NULL DEFAULT 0,
  withheld_amount    NUMERIC(19,4) NOT NULL DEFAULT 0,
  currency_code      CHAR(3) NOT NULL,

  details_json       JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_payout_tax_reports_tenant_payout
  ON payout_tax_reports(tenant_id, payout_id);

-- -------------------------------------------------------------------
-- report_templates: definitions for standard exports (sales, inventory, taxes, payouts)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS report_templates (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  code               TEXT NOT NULL,
  name               TEXT NOT NULL,

  report_type        TEXT NOT NULL
    CHECK (report_type IN ('sales','inventory','tax','payouts','mlm','finance','custom')),

  definition_json    JSONB NOT NULL DEFAULT '{}'::jsonb,

  is_active          BOOLEAN NOT NULL DEFAULT true,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_report_template UNIQUE (tenant_id, code)
);

-- -------------------------------------------------------------------
-- report_exports: async export jobs (CSV/PDF)
-- status: queued/running/done/failed
-- output_uri stored as reference to object storage (S3/minio)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS report_exports (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  template_id         UUID NULL REFERENCES report_templates(id) ON DELETE SET NULL,

  requested_by        UUID NULL,
  report_type         TEXT NOT NULL,

  params_json         JSONB NOT NULL DEFAULT '{}'::jsonb,

  status             TEXT NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued','running','done','failed','cancelled')),

  output_uri          TEXT NULL,
  output_format       TEXT NOT NULL DEFAULT 'csv'
    CHECK (output_format IN ('csv','pdf','xlsx','json')),

  started_at          TIMESTAMPTZ NULL,
  completed_at        TIMESTAMPTZ NULL,
  error_message       TEXT NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

  version             BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_report_exports_tenant_status
  ON report_exports(tenant_id, status, created_at DESC);
