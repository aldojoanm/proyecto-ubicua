-- Flyway V38: Part L – Legal Numbering (Series/Sequences) + Templates + Print Layouts
-- This provides configurable numbering per tenant + location + document type.
-- For concurrency: use FOR UPDATE locking in app when incrementing next_number.

-- -------------------------------------------------------------------
-- e_invoice_series: per tenant sequence for doc_type + series + optional location
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS e_invoice_series (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  doc_type           TEXT NOT NULL,
  doc_series         TEXT NOT NULL,

  location_id        UUID NULL, -- business_locations.id if you want per-branch numbering
  -- Do NOT FK here to avoid dependency order; enforce at app layer or add FK later:
  -- location_id UUID NULL REFERENCES business_locations(id) ON DELETE SET NULL,

  next_number        BIGINT NOT NULL DEFAULT 1 CHECK (next_number > 0),

  padding            INT NOT NULL DEFAULT 0, -- 0=none; else left pad for printing
  prefix             TEXT NULL,
  suffix             TEXT NULL,

  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','paused','closed')),

  effective_from     DATE NULL,
  effective_to       DATE NULL,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_einv_series UNIQUE (tenant_id, doc_type, doc_series, COALESCE(location_id, '00000000-0000-0000-0000-000000000000'::uuid))
);

CREATE INDEX IF NOT EXISTS idx_einv_series_tenant_status
  ON e_invoice_series(tenant_id, status);

-- -------------------------------------------------------------------
-- e_invoice_templates: render templates per tenant (pdf/html) per doc_type
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS e_invoice_templates (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  doc_type           TEXT NOT NULL,

  name               TEXT NOT NULL,
  template_format    TEXT NOT NULL DEFAULT 'html'
    CHECK (template_format IN ('html','mjml','pdf','custom')),

  template_body      TEXT NOT NULL, -- stored template (or reference if large)
  is_default         BOOLEAN NOT NULL DEFAULT false,
  is_active          BOOLEAN NOT NULL DEFAULT true,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_einv_templates_tenant_type
  ON e_invoice_templates(tenant_id, doc_type, is_active);

CREATE UNIQUE INDEX IF NOT EXISTS uq_einv_template_default
  ON e_invoice_templates(tenant_id, doc_type)
  WHERE is_default = true;

-- -------------------------------------------------------------------
-- e_invoice_print_jobs: async generation of PDF/QR (for queues/workers)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS e_invoice_print_jobs (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  e_invoice_id        UUID NOT NULL REFERENCES e_invoice_documents(id) ON DELETE CASCADE,
  template_id         UUID NULL REFERENCES e_invoice_templates(id) ON DELETE SET NULL,

  status             TEXT NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued','running','done','failed','cancelled')),

  output_pdf_uri      TEXT NULL,
  output_qr_uri       TEXT NULL,

  started_at          TIMESTAMPTZ NULL,
  completed_at        TIMESTAMPTZ NULL,
  error_message       TEXT NULL,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_einv_print_jobs_tenant_status
  ON e_invoice_print_jobs(tenant_id, status, created_at DESC);
