-- Flyway V39: Part L – Provider Webhooks (Tax Authority) + Outbox links + RLS
-- Uses app.current_tenant_id() from V4.
-- Note: Part J has provider_webhook_events; Part L adds a dedicated table for e-invoicing callbacks
-- to keep separation of concerns.

-- -------------------------------------------------------------------
-- e_invoice_webhook_events: append-only callbacks from tax authority/provider
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS e_invoice_webhook_events (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  provider            TEXT NOT NULL, -- sin/afip/sii/third_party
  event_type          TEXT NOT NULL,
  provider_event_id   TEXT NULL,

  e_invoice_id        UUID NULL REFERENCES e_invoice_documents(id) ON DELETE SET NULL,

  received_at         TIMESTAMPTZ NOT NULL DEFAULT now(),

  signature_ok        BOOLEAN NOT NULL DEFAULT false,

  payload_json        JSONB NOT NULL,

  processed_status    TEXT NOT NULL DEFAULT 'new'
    CHECK (processed_status IN ('new','processed','failed','ignored')),

  processed_at        TIMESTAMPTZ NULL,
  error_message       TEXT NULL
);

CREATE INDEX IF NOT EXISTS idx_einv_webhooks_tenant_provider_time
  ON e_invoice_webhook_events(tenant_id, provider, received_at DESC);

CREATE INDEX IF NOT EXISTS idx_einv_webhooks_tenant_status
  ON e_invoice_webhook_events(tenant_id, processed_status, received_at DESC);

-- -------------------------------------------------------------------
-- e_invoice_outbox_links: link outbox events to e-invoicing documents
-- (optional convenience; app can publish directly to outbox_events)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS e_invoice_outbox_links (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  outbox_event_id     UUID NOT NULL REFERENCES outbox_events(id) ON DELETE CASCADE,
  e_invoice_id        UUID NOT NULL REFERENCES e_invoice_documents(id) ON DELETE CASCADE,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

  version             BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_einv_outbox_links_tenant_event
  ON e_invoice_outbox_links(tenant_id, outbox_event_id);

-- -------------------------------------------------------------------
-- RLS
-- profiles + documents + history + dedup + signatures + series + templates + print_jobs + webhooks + links
-- -------------------------------------------------------------------
ALTER TABLE e_invoice_profiles        ENABLE ROW LEVEL SECURITY;
ALTER TABLE e_invoice_documents       ENABLE ROW LEVEL SECURITY;
ALTER TABLE e_invoice_status_history  ENABLE ROW LEVEL SECURITY;
ALTER TABLE e_invoice_dedup           ENABLE ROW LEVEL SECURITY;

ALTER TABLE signing_key_refs          ENABLE ROW LEVEL SECURITY;
ALTER TABLE e_invoice_signatures      ENABLE ROW LEVEL SECURITY;

ALTER TABLE e_invoice_series          ENABLE ROW LEVEL SECURITY;
ALTER TABLE e_invoice_templates       ENABLE ROW LEVEL SECURITY;
ALTER TABLE e_invoice_print_jobs      ENABLE ROW LEVEL SECURITY;

ALTER TABLE e_invoice_webhook_events  ENABLE ROW LEVEL SECURITY;
ALTER TABLE e_invoice_outbox_links    ENABLE ROW LEVEL SECURITY;

-- profiles
DROP POLICY IF EXISTS e_invoice_profiles_isolation ON e_invoice_profiles;
CREATE POLICY e_invoice_profiles_isolation ON e_invoice_profiles
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- documents
DROP POLICY IF EXISTS e_invoice_documents_isolation ON e_invoice_documents;
CREATE POLICY e_invoice_documents_isolation ON e_invoice_documents
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- history
DROP POLICY IF EXISTS e_invoice_status_history_isolation ON e_invoice_status_history;
CREATE POLICY e_invoice_status_history_isolation ON e_invoice_status_history
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- dedup
DROP POLICY IF EXISTS e_invoice_dedup_isolation ON e_invoice_dedup;
CREATE POLICY e_invoice_dedup_isolation ON e_invoice_dedup
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- signing keys
DROP POLICY IF EXISTS signing_key_refs_isolation ON signing_key_refs;
CREATE POLICY signing_key_refs_isolation ON signing_key_refs
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- signatures
DROP POLICY IF EXISTS e_invoice_signatures_isolation ON e_invoice_signatures;
CREATE POLICY e_invoice_signatures_isolation ON e_invoice_signatures
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- series
DROP POLICY IF EXISTS e_invoice_series_isolation ON e_invoice_series;
CREATE POLICY e_invoice_series_isolation ON e_invoice_series
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- templates
DROP POLICY IF EXISTS e_invoice_templates_isolation ON e_invoice_templates;
CREATE POLICY e_invoice_templates_isolation ON e_invoice_templates
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- print jobs
DROP POLICY IF EXISTS e_invoice_print_jobs_isolation ON e_invoice_print_jobs;
CREATE POLICY e_invoice_print_jobs_isolation ON e_invoice_print_jobs
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- webhooks
DROP POLICY IF EXISTS e_invoice_webhook_events_isolation ON e_invoice_webhook_events;
CREATE POLICY e_invoice_webhook_events_isolation ON e_invoice_webhook_events
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- outbox links
DROP POLICY IF EXISTS e_invoice_outbox_links_isolation ON e_invoice_outbox_links;
CREATE POLICY e_invoice_outbox_links_isolation ON e_invoice_outbox_links
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
