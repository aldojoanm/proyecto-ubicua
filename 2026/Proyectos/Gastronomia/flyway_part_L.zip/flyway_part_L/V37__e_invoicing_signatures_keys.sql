-- Flyway V37: Part L – Digital Signatures (Key References + Signature Records)
-- IMPORTANT: do NOT store private keys in DB in plaintext.
-- Store references to Vault/KMS/HSM; optionally encrypted blobs with envelope encryption.

-- -------------------------------------------------------------------
-- signing_key_refs: per tenant key references used to sign e-docs
-- key_type: certificate, jwt, xmlsig, etc.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS signing_key_refs (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  key_name           TEXT NOT NULL,
  key_type           TEXT NOT NULL, -- e.g. "x509", "xmlsig", "jwt"
  provider           TEXT NOT NULL DEFAULT 'kms'
    CHECK (provider IN ('kms','vault','hsm','encrypted_db','file_ref')),

  key_ref            TEXT NOT NULL, -- reference/identifier in KMS/Vault
  public_cert_pem    TEXT NULL,     -- optional (public certificate)

  valid_from         DATE NULL,
  valid_to           DATE NULL,

  is_active          BOOLEAN NOT NULL DEFAULT true,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_signing_key_name UNIQUE (tenant_id, key_name)
);

CREATE INDEX IF NOT EXISTS idx_signing_keys_tenant_active
  ON signing_key_refs(tenant_id, is_active);

-- -------------------------------------------------------------------
-- e_invoice_signatures: signature attempts per e-invoice document (append-like)
-- status: created/signed/failed/void
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS e_invoice_signatures (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  e_invoice_id        UUID NOT NULL REFERENCES e_invoice_documents(id) ON DELETE CASCADE,
  signing_key_id      UUID NOT NULL REFERENCES signing_key_refs(id) ON DELETE RESTRICT,

  signature_format   TEXT NOT NULL DEFAULT 'json'
    CHECK (signature_format IN ('json','xml','pdf','jwt','custom')),

  status             TEXT NOT NULL DEFAULT 'created'
    CHECK (status IN ('created','signed','failed','void')),

  signed_at          TIMESTAMPTZ NULL,
  failure_reason     TEXT NULL,

  signature_payload  TEXT NULL, -- small payload or reference
  signature_uri      TEXT NULL, -- storage URI for big signatures

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_einv_signatures_tenant_doc
  ON e_invoice_signatures(tenant_id, e_invoice_id, created_at DESC);
