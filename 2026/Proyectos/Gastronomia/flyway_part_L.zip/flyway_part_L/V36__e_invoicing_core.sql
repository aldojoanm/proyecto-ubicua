-- Flyway V36: Part L – Electronic Invoicing (Core Documents + States + Hashing)
-- Goal: country-agnostic e-invoicing backbone (facturación electrónica), signatures, legal numbering,
--       provider integration, anti-duplicates, and auditable history.
-- Depends on: V24 invoices/invoice_items, V25 idempotency_keys/outbox_events/audit_log, V33 accounting core (optional)

-- -------------------------------------------------------------------
-- e_invoice_profiles: tenant configuration for e-invoicing (per country/provider)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS e_invoice_profiles (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  country_code       CHAR(2) NOT NULL, -- BO, AR, CL, etc.
  provider           TEXT NOT NULL,     -- sin, afip, sii, third_party, sandbox
  environment        TEXT NOT NULL DEFAULT 'sandbox'
    CHECK (environment IN ('sandbox','production')),

  issuer_tax_id      TEXT NULL, -- NIT/CUIT/RUT/RUC
  issuer_legal_name  TEXT NULL,

  issuer_address_json JSONB NULL,

  -- provider credentials are NOT stored raw here; store references (vault/kms) or encrypted blobs.
  credentials_ref    TEXT NULL,

  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','paused','disabled')),

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_e_invoice_profile UNIQUE (tenant_id)
);

-- -------------------------------------------------------------------
-- e_invoice_documents: legal doc representation attached to invoice
-- status:
--  - draft: created but not issued
--  - issued: assigned legal number + hash
--  - submitted: sent to provider/tax authority
--  - accepted: validated/authorized
--  - rejected: rejected by authority
--  - cancelled: cancelled following legal procedure
--  - void: voided internally (never submitted)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS e_invoice_documents (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  invoice_id          UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,

  profile_id          UUID NOT NULL REFERENCES e_invoice_profiles(id) ON DELETE RESTRICT,

  doc_type           TEXT NOT NULL, -- e.g. "invoice", "credit_note", "debit_note"
  doc_series         TEXT NOT NULL, -- e.g. "A", "B", "POS-01"
  legal_number       BIGINT NULL,   -- sequential legal number within series

  -- country-specific unique code (CUF/CUFE/CAE/etc.)
  tax_authority_code TEXT NULL,
  authorization_code TEXT NULL, -- e.g. CAE or similar

  -- immutable hashes for anti-duplicates and audit
  canonical_hash     TEXT NOT NULL, -- sha256 over canonicalized payload
  signed_hash        TEXT NULL,     -- sha256 of signed payload

  -- payload snapshots (avoid huge blobs if possible; store URIs)
  payload_json       JSONB NOT NULL DEFAULT '{}'::jsonb, -- canonical representation
  payload_xml        TEXT NULL, -- optional
  pdf_uri            TEXT NULL, -- storage URI (S3/minio)
  xml_uri            TEXT NULL, -- storage URI
  json_uri           TEXT NULL, -- storage URI

  qr_payload         TEXT NULL, -- for QR codes printed on invoices (country-specific)

  status             TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','issued','submitted','accepted','rejected','cancelled','void')),

  issued_at          TIMESTAMPTZ NULL,
  submitted_at       TIMESTAMPTZ NULL,
  accepted_at        TIMESTAMPTZ NULL,
  rejected_at        TIMESTAMPTZ NULL,
  cancelled_at       TIMESTAMPTZ NULL,

  rejection_reason   TEXT NULL,

  -- provider refs
  provider_doc_ref   TEXT NULL,
  provider_response_json JSONB NULL,

  -- idempotency to avoid duplicates issuing/submitting
  idempotency_key    TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_e_invoice_doc_invoice UNIQUE (tenant_id, invoice_id),
  CONSTRAINT uq_e_invoice_doc_unique_legal UNIQUE (tenant_id, doc_type, doc_series, legal_number),
  CONSTRAINT uq_e_invoice_doc_idempotency UNIQUE (tenant_id, idempotency_key)
    DEFERRABLE INITIALLY IMMEDIATE
);

CREATE INDEX IF NOT EXISTS idx_einv_docs_tenant_status_time
  ON e_invoice_documents(tenant_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_einv_docs_tenant_invoice
  ON e_invoice_documents(tenant_id, invoice_id);

CREATE INDEX IF NOT EXISTS idx_einv_docs_tax_code
  ON e_invoice_documents(tenant_id, tax_authority_code);

-- -------------------------------------------------------------------
-- e_invoice_status_history: append-only state transitions for audit
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS e_invoice_status_history (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  e_invoice_id        UUID NOT NULL REFERENCES e_invoice_documents(id) ON DELETE CASCADE,

  from_status        TEXT NULL,
  to_status          TEXT NOT NULL,
  changed_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  changed_by         UUID NULL,

  note               TEXT NULL,
  details_json       JSONB NULL
);

CREATE INDEX IF NOT EXISTS idx_einv_history_tenant_doc_time
  ON e_invoice_status_history(tenant_id, e_invoice_id, changed_at DESC);

-- -------------------------------------------------------------------
-- e_invoice_dedup: protects against duplicates for same payload hash (within tenant+doc_type+series)
-- If you reissue same invoice, you should create credit_note, not duplicate invoice.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS e_invoice_dedup (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  doc_type           TEXT NOT NULL,
  doc_series         TEXT NOT NULL,
  canonical_hash     TEXT NOT NULL,

  e_invoice_id        UUID NOT NULL REFERENCES e_invoice_documents(id) ON DELETE CASCADE,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),

  PRIMARY KEY (tenant_id, doc_type, doc_series, canonical_hash)
);
