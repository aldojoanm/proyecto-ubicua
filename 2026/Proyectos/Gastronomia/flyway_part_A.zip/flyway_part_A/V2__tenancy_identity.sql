-- Flyway V2: Tenancy + Settings + Memberships + API Keys (Part A)
-- Multi-tenant physical model: every domain table has tenant_id + RLS (policies added later).

CREATE TABLE IF NOT EXISTS tenants (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name               TEXT NOT NULL,

  country_code        CHAR(2) NOT NULL,
  currency_code       CHAR(3) NOT NULL,   -- ISO 4217 default currency for tenant
  timezone            TEXT NOT NULL,      -- IANA e.g. America/La_Paz
  default_language    TEXT NOT NULL,      -- e.g. es, en, pt-BR

  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','suspended')),

  -- audit
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  -- optimistic concurrency
  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants(status);

CREATE TABLE IF NOT EXISTS tenant_settings (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  settings_json      JSONB NOT NULL DEFAULT '{}'::jsonb,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_tenant_settings_one_per_tenant UNIQUE (tenant_id)
);

CREATE TABLE IF NOT EXISTS memberships (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  user_id            UUID NOT NULL, -- IAM subject / user UUID
  role               TEXT NOT NULL
    CHECK (role IN (
      'OWNER','ADMIN','MANAGER','STAFF','KITCHEN','CASHIER',
      'PARTNER_MANAGER','FINANCE'
    )),

  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','invited','disabled')),

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_membership_tenant_user UNIQUE (tenant_id, user_id, role)
);

CREATE INDEX IF NOT EXISTS idx_memberships_tenant_user ON memberships(tenant_id, user_id);
CREATE INDEX IF NOT EXISTS idx_memberships_tenant_role ON memberships(tenant_id, role);

CREATE TABLE IF NOT EXISTS api_keys (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  name               TEXT NOT NULL,
  key_hash           TEXT NOT NULL, -- store hash only (never the raw key)
  scopes             TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  expires_at         TIMESTAMPTZ NULL,
  revoked_at         TIMESTAMPTZ NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_api_keys_tenant ON api_keys(tenant_id);
CREATE INDEX IF NOT EXISTS idx_api_keys_tenant_revoked ON api_keys(tenant_id, revoked_at);
