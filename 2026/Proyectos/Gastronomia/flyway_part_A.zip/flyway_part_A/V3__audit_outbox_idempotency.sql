-- Flyway V3: Audit Log + Outbox + Idempotency Keys (Part A)
-- These are cross-cutting tables used by all services.

CREATE TABLE IF NOT EXISTS audit_log (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  actor_user_id      UUID NULL,
  actor_role         TEXT NULL,
  ip_address         INET NULL,
  user_agent         TEXT NULL,

  action             TEXT NOT NULL,
  entity_type        TEXT NOT NULL,
  entity_id          UUID NULL,

  before_json        JSONB NULL,
  after_json         JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_log_tenant_time ON audit_log(tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON audit_log(tenant_id, entity_type, entity_id);

CREATE TABLE IF NOT EXISTS outbox_events (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  event_type         TEXT NOT NULL,
  aggregate_type     TEXT NULL,
  aggregate_id       UUID NULL,

  payload_json       JSONB NOT NULL,
  headers_json       JSONB NOT NULL DEFAULT '{}'::jsonb,

  status             TEXT NOT NULL DEFAULT 'new'
    CHECK (status IN ('new','processed','failed')),

  attempts           INT NOT NULL DEFAULT 0,
  last_error         TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at       TIMESTAMPTZ NULL,
  created_by         UUID NULL
);

CREATE INDEX IF NOT EXISTS idx_outbox_tenant_status_time
  ON outbox_events(tenant_id, status, created_at);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  idem_key           TEXT NOT NULL,
  endpoint           TEXT NOT NULL,
  request_hash       TEXT NOT NULL,

  response_json      JSONB NULL,
  http_status        INT NULL,
  locked_at          TIMESTAMPTZ NULL,
  expires_at         TIMESTAMPTZ NOT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_idempotency UNIQUE (tenant_id, idem_key, endpoint)
);

CREATE INDEX IF NOT EXISTS idx_idempotency_tenant_expires ON idempotency_keys(tenant_id, expires_at);
