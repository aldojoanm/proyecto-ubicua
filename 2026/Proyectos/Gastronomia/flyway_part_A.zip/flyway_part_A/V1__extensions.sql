-- Flyway V1: Extensions required by GastroLink AI (Part A)
-- NOTE: Run as a superuser / a role with CREATE EXTENSION privileges.

CREATE EXTENSION IF NOT EXISTS pgcrypto;      -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS citext;        -- case-insensitive email, etc.
CREATE EXTENSION IF NOT EXISTS postgis;       -- geo (GEOGRAPHY/GEOMETRY)
-- pgvector is used for embeddings (enabled now, used in Part F/G)
CREATE EXTENSION IF NOT EXISTS vector;

-- Helpful: btree_gist for exclusion constraints (optional)
CREATE EXTENSION IF NOT EXISTS btree_gist;
