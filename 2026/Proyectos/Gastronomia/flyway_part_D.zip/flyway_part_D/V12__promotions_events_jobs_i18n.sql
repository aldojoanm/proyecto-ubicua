-- Flyway V12: Part D – i18n for Promotions, Events, Jobs

CREATE TABLE IF NOT EXISTS promotion_i18n (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  promotion_id        UUID NOT NULL REFERENCES promotions(id) ON DELETE CASCADE,

  lang               TEXT NOT NULL,

  title              TEXT NOT NULL,
  description        TEXT NULL,
  terms              TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_promo_i18n UNIQUE (tenant_id, promotion_id, lang)
);

CREATE INDEX IF NOT EXISTS idx_promo_i18n_lang
  ON promotion_i18n(tenant_id, lang);

CREATE TABLE IF NOT EXISTS event_i18n (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  event_id            UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,

  lang               TEXT NOT NULL,

  title              TEXT NOT NULL,
  description        TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_event_i18n UNIQUE (tenant_id, event_id, lang)
);

CREATE INDEX IF NOT EXISTS idx_event_i18n_lang
  ON event_i18n(tenant_id, lang);

CREATE TABLE IF NOT EXISTS job_i18n (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  job_id              UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,

  lang               TEXT NOT NULL,

  title              TEXT NOT NULL,
  description        TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_job_i18n UNIQUE (tenant_id, job_id, lang)
);

CREATE INDEX IF NOT EXISTS idx_job_i18n_lang
  ON job_i18n(tenant_id, lang);
