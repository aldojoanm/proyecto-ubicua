-- Flyway V13: Part D – RLS enable + baseline tenant policies
-- Uses app.current_tenant_id() from V4.

ALTER TABLE promotions            ENABLE ROW LEVEL SECURITY;
ALTER TABLE promotion_rules       ENABLE ROW LEVEL SECURITY;
ALTER TABLE promotion_media_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE promotion_i18n        ENABLE ROW LEVEL SECURITY;

ALTER TABLE events                ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_artists         ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_media_links     ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_i18n            ENABLE ROW LEVEL SECURITY;

ALTER TABLE jobs                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_i18n              ENABLE ROW LEVEL SECURITY;

-- promotions
DROP POLICY IF EXISTS promotions_isolation ON promotions;
CREATE POLICY promotions_isolation ON promotions
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS promotion_rules_isolation ON promotion_rules;
CREATE POLICY promotion_rules_isolation ON promotion_rules
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS promotion_media_links_isolation ON promotion_media_links;
CREATE POLICY promotion_media_links_isolation ON promotion_media_links
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS promotion_i18n_isolation ON promotion_i18n;
CREATE POLICY promotion_i18n_isolation ON promotion_i18n
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- events
DROP POLICY IF EXISTS events_isolation ON events;
CREATE POLICY events_isolation ON events
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS event_artists_isolation ON event_artists;
CREATE POLICY event_artists_isolation ON event_artists
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS event_media_links_isolation ON event_media_links;
CREATE POLICY event_media_links_isolation ON event_media_links
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS event_i18n_isolation ON event_i18n;
CREATE POLICY event_i18n_isolation ON event_i18n
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- jobs
DROP POLICY IF EXISTS jobs_isolation ON jobs;
CREATE POLICY jobs_isolation ON jobs
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS job_i18n_isolation ON job_i18n;
CREATE POLICY job_i18n_isolation ON job_i18n
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
