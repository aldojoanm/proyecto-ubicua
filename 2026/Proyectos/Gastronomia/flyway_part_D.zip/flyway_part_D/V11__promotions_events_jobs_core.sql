-- Flyway V11: Part D – Promotions + Events + Jobs (core)
-- Depends on: V2 tenants, V5 businesses, V5 business_locations, V4 app schema for RLS

-- promotions
CREATE TABLE IF NOT EXISTS promotions (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  location_id         UUID NULL REFERENCES business_locations(id) ON DELETE SET NULL,

  title              TEXT NOT NULL,
  description        TEXT NULL,
  terms              TEXT NULL,

  starts_at          TIMESTAMPTZ NOT NULL,
  ends_at            TIMESTAMPTZ NOT NULL,

  status             TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','active','paused','expired','archived')),

  promo_type         TEXT NOT NULL DEFAULT 'general'
    CHECK (promo_type IN ('general','discount','happy_hour','coupon','bundle','limited_time')),

  amount_from        NUMERIC(19,4) NULL,
  amount_to          NUMERIC(19,4) NULL,
  currency_code      CHAR(3) NULL,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT ck_promo_time CHECK (starts_at < ends_at)
);

CREATE INDEX IF NOT EXISTS idx_promos_tenant_status_time
  ON promotions(tenant_id, status, starts_at, ends_at);
CREATE INDEX IF NOT EXISTS idx_promos_tenant_business
  ON promotions(tenant_id, business_id);
CREATE INDEX IF NOT EXISTS idx_promos_tenant_location
  ON promotions(tenant_id, location_id);

-- promotion_rules
CREATE TABLE IF NOT EXISTS promotion_rules (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  promotion_id        UUID NOT NULL REFERENCES promotions(id) ON DELETE CASCADE,

  rule_type          TEXT NOT NULL
    CHECK (rule_type IN ('min_spend','day_only','time_window','coupon_code','limit_per_user','first_time_only')),

  rule_json          JSONB NOT NULL DEFAULT '{}'::jsonb,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_promo_rules_tenant_promo
  ON promotion_rules(tenant_id, promotion_id);

-- promotion_media_links (bridge to Mongo)
CREATE TABLE IF NOT EXISTS promotion_media_links (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  promotion_id        UUID NOT NULL REFERENCES promotions(id) ON DELETE CASCADE,

  media_asset_ref     TEXT NOT NULL,
  kind               TEXT NOT NULL DEFAULT 'image'
    CHECK (kind IN ('image','video')),

  sort_order         INT NOT NULL DEFAULT 0,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  PRIMARY KEY (tenant_id, promotion_id, media_asset_ref)
);

CREATE INDEX IF NOT EXISTS idx_promo_media_sort
  ON promotion_media_links(tenant_id, promotion_id, sort_order);

-- events
CREATE TABLE IF NOT EXISTS events (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  location_id         UUID NULL REFERENCES business_locations(id) ON DELETE SET NULL,

  title              TEXT NOT NULL,
  description        TEXT NULL,

  starts_at          TIMESTAMPTZ NOT NULL,
  ends_at            TIMESTAMPTZ NOT NULL,

  status             TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','published','cancelled','archived')),

  price_amount       NUMERIC(19,4) NULL,
  currency_code      CHAR(3) NULL,

  capacity           INT NULL CHECK (capacity IS NULL OR capacity >= 0),

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT ck_event_time CHECK (starts_at < ends_at)
);

CREATE INDEX IF NOT EXISTS idx_events_tenant_status_time
  ON events(tenant_id, status, starts_at, ends_at);
CREATE INDEX IF NOT EXISTS idx_events_tenant_business
  ON events(tenant_id, business_id);
CREATE INDEX IF NOT EXISTS idx_events_tenant_location
  ON events(tenant_id, location_id);

-- event_artists
CREATE TABLE IF NOT EXISTS event_artists (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  event_id            UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,

  name               TEXT NOT NULL,
  genre              TEXT NULL,
  contact            TEXT NULL,

  sort_order         INT NOT NULL DEFAULT 0,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_event_artists_tenant_event
  ON event_artists(tenant_id, event_id);

-- event_media_links (bridge to Mongo)
CREATE TABLE IF NOT EXISTS event_media_links (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  event_id            UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,

  media_asset_ref     TEXT NOT NULL,
  kind               TEXT NOT NULL DEFAULT 'image'
    CHECK (kind IN ('image','video')),

  sort_order         INT NOT NULL DEFAULT 0,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  PRIMARY KEY (tenant_id, event_id, media_asset_ref)
);

CREATE INDEX IF NOT EXISTS idx_event_media_sort
  ON event_media_links(tenant_id, event_id, sort_order);

-- jobs
CREATE TABLE IF NOT EXISTS jobs (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  location_id         UUID NULL REFERENCES business_locations(id) ON DELETE SET NULL,

  title              TEXT NOT NULL,
  description        TEXT NULL,

  employment_type    TEXT NOT NULL DEFAULT 'full_time'
    CHECK (employment_type IN ('full_time','part_time','contract','temporary')),

  salary_min         NUMERIC(19,4) NULL,
  salary_max         NUMERIC(19,4) NULL,
  currency_code      CHAR(3) NULL,

  contact_phone      TEXT NULL,
  contact_whatsapp   TEXT NULL,
  contact_email      TEXT NULL,

  status             TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','published','closed','archived')),

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_jobs_tenant_status
  ON jobs(tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_jobs_tenant_business
  ON jobs(tenant_id, business_id);
CREATE INDEX IF NOT EXISTS idx_jobs_tenant_location
  ON jobs(tenant_id, location_id);
