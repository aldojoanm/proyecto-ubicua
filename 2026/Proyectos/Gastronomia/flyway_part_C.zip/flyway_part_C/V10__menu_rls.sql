-- Flyway V10: RLS enable + baseline policies for Menu tables (Part C)
-- Uses app.current_tenant_id() from V4.

ALTER TABLE menu_definitions       ENABLE ROW LEVEL SECURITY;
ALTER TABLE menu_categories        ENABLE ROW LEVEL SECURITY;
ALTER TABLE menu_items             ENABLE ROW LEVEL SECURITY;
ALTER TABLE menu_item_variants     ENABLE ROW LEVEL SECURITY;
ALTER TABLE menu_item_availability ENABLE ROW LEVEL SECURITY;
ALTER TABLE menu_item_media_links  ENABLE ROW LEVEL SECURITY;
ALTER TABLE menu_item_i18n         ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS menu_definitions_isolation ON menu_definitions;
CREATE POLICY menu_definitions_isolation ON menu_definitions
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS menu_categories_isolation ON menu_categories;
CREATE POLICY menu_categories_isolation ON menu_categories
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS menu_items_isolation ON menu_items;
CREATE POLICY menu_items_isolation ON menu_items
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS menu_item_variants_isolation ON menu_item_variants;
CREATE POLICY menu_item_variants_isolation ON menu_item_variants
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS menu_item_availability_isolation ON menu_item_availability;
CREATE POLICY menu_item_availability_isolation ON menu_item_availability
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS menu_item_media_links_isolation ON menu_item_media_links;
CREATE POLICY menu_item_media_links_isolation ON menu_item_media_links
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS menu_item_i18n_isolation ON menu_item_i18n;
CREATE POLICY menu_item_i18n_isolation ON menu_item_i18n
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
