-- Flyway V8: Menu (Part C) – Menu Definitions + Categories + Items (core)
-- Depends on: V2 tenants, V5 businesses, V4 app schema for tenant scoping (RLS later)

-- -------------------------------------------------------------------
-- menu_definitions: a business can have multiple menus (e.g., Main, Drinks, Late Night)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu_definitions (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  business_id         UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

  name               TEXT NOT NULL,
  status             TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','published','archived')),

  valid_from         DATE NULL,
  valid_to           DATE NULL,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_menu_defs_tenant_business
  ON menu_definitions(tenant_id, business_id);

CREATE INDEX IF NOT EXISTS idx_menu_defs_status
  ON menu_definitions(tenant_id, status);

-- -------------------------------------------------------------------
-- menu_categories: ordered sections within a menu
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu_categories (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  menu_id             UUID NOT NULL REFERENCES menu_definitions(id) ON DELETE CASCADE,

  name               TEXT NOT NULL,
  sort_order         INT NOT NULL DEFAULT 0,
  is_active          BOOLEAN NOT NULL DEFAULT true,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_menu_category_order UNIQUE (tenant_id, menu_id, sort_order)
);

CREATE INDEX IF NOT EXISTS idx_menu_categories_tenant_menu
  ON menu_categories(tenant_id, menu_id);

-- -------------------------------------------------------------------
-- menu_items: products/dishes inside categories
-- Includes multimoneda columns (amount + currency_code) and flexible JSONB
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu_items (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  category_id         UUID NOT NULL REFERENCES menu_categories(id) ON DELETE CASCADE,

  name               TEXT NOT NULL,
  description        TEXT NULL,

  sku                TEXT NULL,        -- optional internal SKU
  is_active          BOOLEAN NOT NULL DEFAULT true,
  is_available_now   BOOLEAN NOT NULL DEFAULT true, -- computed/maintained by app if desired

  base_price         NUMERIC(19,4) NOT NULL DEFAULT 0,
  currency_code      CHAR(3) NOT NULL, -- ISO 4217 (default from tenant, app fills it)

  tax_code           TEXT NULL,        -- optional (VAT category, etc.)
  allergens_json     JSONB NOT NULL DEFAULT '[]'::jsonb, -- array of strings
  nutrition_json     JSONB NULL,       -- flexible nutrition facts

  prep_time_minutes  INT NULL CHECK (prep_time_minutes IS NULL OR prep_time_minutes >= 0),

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_menu_items_tenant_category
  ON menu_items(tenant_id, category_id);

CREATE INDEX IF NOT EXISTS idx_menu_items_active
  ON menu_items(tenant_id, is_active);
