-- Flyway V9: Menu (Part C) – Variants, Availability Windows, Media Links, i18n

-- -------------------------------------------------------------------
-- menu_item_variants: sizes/options with price deltas
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu_item_variants (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  item_id             UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,

  name               TEXT NOT NULL,      -- e.g. "Small", "Large", "500ml"
  price_delta        NUMERIC(19,4) NOT NULL DEFAULT 0,
  currency_code      CHAR(3) NOT NULL,   -- same currency as base (app enforces)

  sort_order         INT NOT NULL DEFAULT 0,
  is_active          BOOLEAN NOT NULL DEFAULT true,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_variant_name UNIQUE (tenant_id, item_id, name)
);

CREATE INDEX IF NOT EXISTS idx_variants_tenant_item
  ON menu_item_variants(tenant_id, item_id);

-- -------------------------------------------------------------------
-- menu_item_availability: weekly time windows
-- day_of_week: 0..6 (Sun..Sat)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu_item_availability (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  item_id             UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,

  day_of_week         SMALLINT NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  start_time          TIME NOT NULL,
  end_time            TIME NOT NULL,
  is_available        BOOLEAN NOT NULL DEFAULT true,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT ck_avail_time_window CHECK (start_time < end_time),
  CONSTRAINT uq_item_avail UNIQUE (tenant_id, item_id, day_of_week, start_time, end_time)
);

CREATE INDEX IF NOT EXISTS idx_avail_tenant_item
  ON menu_item_availability(tenant_id, item_id);

-- -------------------------------------------------------------------
-- menu_item_media_links: bridge to MongoDB media_assets
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu_item_media_links (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  item_id             UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,

  media_asset_ref     TEXT NOT NULL, -- Mongo _id or storage key
  kind               TEXT NOT NULL DEFAULT 'image'
    CHECK (kind IN ('image','video')),

  sort_order         INT NOT NULL DEFAULT 0,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  PRIMARY KEY (tenant_id, item_id, media_asset_ref)
);

CREATE INDEX IF NOT EXISTS idx_item_media_sort
  ON menu_item_media_links(tenant_id, item_id, sort_order);

-- -------------------------------------------------------------------
-- i18n for menu items
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu_item_i18n (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  item_id             UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,

  lang               TEXT NOT NULL,

  name               TEXT NOT NULL,
  description        TEXT NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_menu_item_i18n UNIQUE (tenant_id, item_id, lang)
);

CREATE INDEX IF NOT EXISTS idx_item_i18n_lang
  ON menu_item_i18n(tenant_id, lang);
