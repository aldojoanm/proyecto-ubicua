-- Flyway V28: Part I – Commission Plans (versioned) + Ledger (append-only) + Payouts
-- Depends on: V27 partner tables, V25 idempotency_keys (for payouts), V26 RLS base available

-- -------------------------------------------------------------------
-- commission_plans: versioned rules per tenant+project
-- rules_json sample:
-- {
--   "levels": [{"level":1,"pct":0.10},{"level":2,"pct":0.05},{"level":3,"pct":0.02}],
--   "minPayout": 10,
--   "cooldownDays": 7,
--   "bonuses": [{"type":"activation","amount":5}]
-- }
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS commission_plans (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  project_id          UUID NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,

  plan_version       INT NOT NULL DEFAULT 1 CHECK (plan_version > 0),

  effective_from     TIMESTAMPTZ NOT NULL DEFAULT now(),
  effective_to       TIMESTAMPTZ NULL,

  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','archived')),

  rules_json         JSONB NOT NULL DEFAULT '{}'::jsonb,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_commission_plan UNIQUE (tenant_id, project_id, plan_version),
  CONSTRAINT ck_commission_plan_time CHECK (effective_to IS NULL OR effective_from < effective_to)
);

CREATE INDEX IF NOT EXISTS idx_commission_plans_tenant_project_time
  ON commission_plans(tenant_id, project_id, effective_from DESC);

-- -------------------------------------------------------------------
-- partner_attributions: links a conversion event to a referral source
-- event_type examples: signup, subscription_paid, upgrade, purchase
-- event_id is UUID of the triggering entity (e.g., subscription, invoice, order)
-- This table enables deterministic attribution and reprocessing.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS partner_attributions (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  project_id          UUID NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,

  referred_partner_project_id UUID NULL REFERENCES partner_projects(id) ON DELETE SET NULL,
  referral_code_id    UUID NULL REFERENCES referral_codes(id) ON DELETE SET NULL,

  event_type         TEXT NOT NULL,
  event_id           UUID NOT NULL,

  attributed_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_attribution UNIQUE (tenant_id, project_id, event_type, event_id)
);

CREATE INDEX IF NOT EXISTS idx_attrib_tenant_project_time
  ON partner_attributions(tenant_id, project_id, attributed_at DESC);

-- -------------------------------------------------------------------
-- commission_ledger: APPEND-ONLY
-- status flow: pending -> released -> paid OR reversed
-- Important: do NOT hard-delete ledger rows; use reversal entries when needed.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS commission_ledger (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  project_id          UUID NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,

  partner_project_id  UUID NOT NULL REFERENCES partner_projects(id) ON DELETE RESTRICT,

  source_event_type  TEXT NOT NULL, -- same as attribution event_type
  source_event_id    UUID NOT NULL,

  level              SMALLINT NOT NULL DEFAULT 1 CHECK (level BETWEEN 1 AND 10),

  amount             NUMERIC(19,4) NOT NULL,
  currency_code      CHAR(3) NOT NULL,

  status             TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','released','paid','reversed')),

  release_at         TIMESTAMPTZ NULL, -- when becomes eligible
  paid_at            TIMESTAMPTZ NULL,

  note               TEXT NULL,
  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL
);

CREATE INDEX IF NOT EXISTS idx_comm_ledger_tenant_partner_status
  ON commission_ledger(tenant_id, partner_project_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_comm_ledger_tenant_project_status
  ON commission_ledger(tenant_id, project_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_comm_ledger_source
  ON commission_ledger(tenant_id, source_event_type, source_event_id);

-- -------------------------------------------------------------------
-- partner_balances: current available/pending totals (materialized balance)
-- Keep in sync via job/trigger in app; ledger remains the SoT.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS partner_balances (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  partner_project_id  UUID NOT NULL REFERENCES partner_projects(id) ON DELETE CASCADE,

  pending_amount      NUMERIC(19,4) NOT NULL DEFAULT 0,
  available_amount    NUMERIC(19,4) NOT NULL DEFAULT 0,
  paid_amount         NUMERIC(19,4) NOT NULL DEFAULT 0,

  currency_code       CHAR(3) NOT NULL,

  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

  version             BIGINT NOT NULL DEFAULT 0,

  PRIMARY KEY (tenant_id, partner_project_id)
);

CREATE INDEX IF NOT EXISTS idx_partner_balances_tenant_available
  ON partner_balances(tenant_id, available_amount DESC);

-- -------------------------------------------------------------------
-- payout_requests: payout workflow
-- idempotency_key allows safe retries (also can reuse global idempotency_keys table)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payout_requests (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  project_id          UUID NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,
  partner_project_id  UUID NOT NULL REFERENCES partner_projects(id) ON DELETE RESTRICT,

  amount             NUMERIC(19,4) NOT NULL CHECK (amount > 0),
  currency_code      CHAR(3) NOT NULL,

  method             TEXT NOT NULL
    CHECK (method IN ('bank','qr','transfer','wallet')),

  payout_details_json JSONB NULL,

  status             TEXT NOT NULL DEFAULT 'requested'
    CHECK (status IN ('requested','approved','paid','rejected','cancelled')),

  requested_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  approved_at        TIMESTAMPTZ NULL,
  approved_by        UUID NULL,
  processed_at       TIMESTAMPTZ NULL,

  provider           TEXT NULL,
  provider_ref       TEXT NULL,

  idempotency_key    TEXT NULL, -- can also be stored in idempotency_keys table

  notes              TEXT NULL,
  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_payouts_tenant_partner_status
  ON payout_requests(tenant_id, partner_project_id, status, requested_at DESC);

CREATE INDEX IF NOT EXISTS idx_payouts_tenant_project_status
  ON payout_requests(tenant_id, project_id, status, requested_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS uq_payout_idempotency
  ON payout_requests(tenant_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

-- -------------------------------------------------------------------
-- payout_items: link payout to ledger rows (so we can mark them paid)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payout_items (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  payout_id           UUID NOT NULL REFERENCES payout_requests(id) ON DELETE CASCADE,
  ledger_id           UUID NOT NULL REFERENCES commission_ledger(id) ON DELETE RESTRICT,

  PRIMARY KEY (tenant_id, payout_id, ledger_id)
);

CREATE INDEX IF NOT EXISTS idx_payout_items_payout
  ON payout_items(tenant_id, payout_id);
