-- Flyway V27: Part I – Partner Program (MLM without stigma) – Core Entities
-- Goal: partner management per project (GastroLink, ArgoDelivery, ArgoTransporte, etc.)
-- Notes:
--  - Keep language neutral: "Partner Program", "Affiliates", "Referral Network"
--  - Multi-tenant strict: tenant_id + RLS
--  - Append-only ledgers in V28
-- Depends on: V2 tenants, V25 audit_log (optional), V4 app schema for RLS

-- -------------------------------------------------------------------
-- projects (global catalog)
-- Each project has its own partner program space (metrics, plans, ledgers).
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS projects (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code               TEXT NOT NULL UNIQUE, -- e.g. GASTROLINK, ARGO_DELIVERY
  name               TEXT NOT NULL,

  is_active          BOOLEAN NOT NULL DEFAULT true,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_projects_active
  ON projects(is_active);

-- -------------------------------------------------------------------
-- partners: partner identity per tenant (links to IAM user)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS partners (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  user_id            UUID NOT NULL, -- IAM user

  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','suspended','closed')),

  display_name       TEXT NULL, -- optional public alias (avoid PII in logs)
  phone              TEXT NULL, -- optional (if stored, treat as PII)
  email              TEXT NULL, -- optional (if stored, treat as PII)

  joined_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_partner_user UNIQUE (tenant_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_partners_tenant_status
  ON partners(tenant_id, status);

-- -------------------------------------------------------------------
-- partner_projects: enroll partner into a project's program space
-- A partner may join multiple projects within same tenant.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS partner_projects (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  partner_id          UUID NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
  project_id          UUID NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,

  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','paused','closed')),

  joined_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- OPTIONAL: allow storing "preferred payout method" per project
  payout_method      TEXT NULL
    CHECK (payout_method IS NULL OR payout_method IN ('bank','qr','transfer','wallet')),

  payout_details_json JSONB NULL,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_partner_project UNIQUE (tenant_id, partner_id, project_id)
);

CREATE INDEX IF NOT EXISTS idx_partner_projects_tenant_project_status
  ON partner_projects(tenant_id, project_id, status);

CREATE INDEX IF NOT EXISTS idx_partner_projects_tenant_partner
  ON partner_projects(tenant_id, partner_id);

-- -------------------------------------------------------------------
-- referral_codes: one or more codes per partner_project (campaigns, channels)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS referral_codes (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  partner_project_id  UUID NOT NULL REFERENCES partner_projects(id) ON DELETE CASCADE,

  code               TEXT NOT NULL,
  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','paused','revoked')),

  campaign           TEXT NULL, -- optional tag (e.g. "TIKTOK_JAN")
  channel            TEXT NULL, -- optional (tiktok/ig/qr/offline)

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_referral_code UNIQUE (tenant_id, code)
);

CREATE INDEX IF NOT EXISTS idx_ref_codes_tenant_partner_project
  ON referral_codes(tenant_id, partner_project_id, status);

-- -------------------------------------------------------------------
-- referral_clicks: low-PII tracking (store hashes, not raw IP/UA)
-- This enables attribution + fraud signals without stigma.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS referral_clicks (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  partner_project_id  UUID NOT NULL REFERENCES partner_projects(id) ON DELETE CASCADE,
  referral_code_id    UUID NULL REFERENCES referral_codes(id) ON DELETE SET NULL,

  clicked_at         TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- privacy-friendly signals
  ip_hash            TEXT NULL,
  ua_hash            TEXT NULL,
  device_fingerprint_hash TEXT NULL,

  utm_source         TEXT NULL,
  utm_medium         TEXT NULL,
  utm_campaign       TEXT NULL,

  metadata           JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ref_clicks_tenant_project_time
  ON referral_clicks(tenant_id, partner_project_id, clicked_at DESC);

CREATE INDEX IF NOT EXISTS idx_ref_clicks_tenant_code_time
  ON referral_clicks(tenant_id, referral_code_id, clicked_at DESC);

-- -------------------------------------------------------------------
-- partner_tree_edges: adjacency list for 1..N levels (we'll enforce max levels in app)
-- parent_partner_project_id NULL => root
-- level: 1 = direct parent, 2 = grandparent, etc. (typically max 3)
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS partner_tree_edges (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id                UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  partner_project_id        UUID NOT NULL REFERENCES partner_projects(id) ON DELETE CASCADE,
  parent_partner_project_id UUID NULL REFERENCES partner_projects(id) ON DELETE SET NULL,

  level                    SMALLINT NOT NULL CHECK (level BETWEEN 1 AND 10),

  created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by               UUID NULL,

  version                  BIGINT NOT NULL DEFAULT 0,

  CONSTRAINT uq_tree_edge UNIQUE (tenant_id, partner_project_id)
);

CREATE INDEX IF NOT EXISTS idx_tree_edges_tenant_parent
  ON partner_tree_edges(tenant_id, parent_partner_project_id);

CREATE INDEX IF NOT EXISTS idx_tree_edges_tenant_level
  ON partner_tree_edges(tenant_id, level);
