-- Flyway V29: Part I – Fraud Signals + RLS policies
-- Depends on: V27/V28 tables, V4 app schema for RLS

-- -------------------------------------------------------------------
-- fraud_flags: signals raised by rules/IA to protect the program
-- signal_type examples: multi_clicks, suspicious_ip, velocity, chargeback, collusion
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fraud_flags (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  project_id          UUID NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,
  partner_project_id  UUID NOT NULL REFERENCES partner_projects(id) ON DELETE CASCADE,

  signal_type        TEXT NOT NULL,
  score              NUMERIC(10,4) NOT NULL DEFAULT 0,

  status             TEXT NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','reviewing','cleared','confirmed')),

  details_json       JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_fraud_flags_tenant_partner_status
  ON fraud_flags(tenant_id, partner_project_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_fraud_flags_tenant_project_status
  ON fraud_flags(tenant_id, project_id, status, created_at DESC);

-- -------------------------------------------------------------------
-- Enable RLS
-- Projects are global (no tenant_id) => no RLS.
-- -------------------------------------------------------------------
ALTER TABLE partners              ENABLE ROW LEVEL SECURITY;
ALTER TABLE partner_projects      ENABLE ROW LEVEL SECURITY;
ALTER TABLE referral_codes        ENABLE ROW LEVEL SECURITY;
ALTER TABLE referral_clicks       ENABLE ROW LEVEL SECURITY;
ALTER TABLE partner_tree_edges    ENABLE ROW LEVEL SECURITY;

ALTER TABLE commission_plans      ENABLE ROW LEVEL SECURITY;
ALTER TABLE partner_attributions  ENABLE ROW LEVEL SECURITY;
ALTER TABLE commission_ledger     ENABLE ROW LEVEL SECURITY;
ALTER TABLE partner_balances      ENABLE ROW LEVEL SECURITY;

ALTER TABLE payout_requests       ENABLE ROW LEVEL SECURITY;
ALTER TABLE payout_items          ENABLE ROW LEVEL SECURITY;

ALTER TABLE fraud_flags           ENABLE ROW LEVEL SECURITY;

-- partners
DROP POLICY IF EXISTS partners_isolation ON partners;
CREATE POLICY partners_isolation ON partners
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- partner_projects
DROP POLICY IF EXISTS partner_projects_isolation ON partner_projects;
CREATE POLICY partner_projects_isolation ON partner_projects
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- referral_codes
DROP POLICY IF EXISTS referral_codes_isolation ON referral_codes;
CREATE POLICY referral_codes_isolation ON referral_codes
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- referral_clicks
DROP POLICY IF EXISTS referral_clicks_isolation ON referral_clicks;
CREATE POLICY referral_clicks_isolation ON referral_clicks
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- tree edges
DROP POLICY IF EXISTS partner_tree_edges_isolation ON partner_tree_edges;
CREATE POLICY partner_tree_edges_isolation ON partner_tree_edges
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- commission_plans
DROP POLICY IF EXISTS commission_plans_isolation ON commission_plans;
CREATE POLICY commission_plans_isolation ON commission_plans
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- partner_attributions
DROP POLICY IF EXISTS partner_attributions_isolation ON partner_attributions;
CREATE POLICY partner_attributions_isolation ON partner_attributions
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- commission_ledger
DROP POLICY IF EXISTS commission_ledger_isolation ON commission_ledger;
CREATE POLICY commission_ledger_isolation ON commission_ledger
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- partner_balances
DROP POLICY IF EXISTS partner_balances_isolation ON partner_balances;
CREATE POLICY partner_balances_isolation ON partner_balances
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- payouts
DROP POLICY IF EXISTS payout_requests_isolation ON payout_requests;
CREATE POLICY payout_requests_isolation ON payout_requests
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS payout_items_isolation ON payout_items;
CREATE POLICY payout_items_isolation ON payout_items
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- fraud
DROP POLICY IF EXISTS fraud_flags_isolation ON fraud_flags;
CREATE POLICY fraud_flags_isolation ON fraud_flags
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
