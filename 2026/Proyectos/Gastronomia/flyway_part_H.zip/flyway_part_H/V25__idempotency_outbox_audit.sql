-- Flyway V25: Part H – Idempotency + Outbox + Audit Log (integration backbone)
-- Depends on: V2 tenants, V4 app schema for RLS

-- -------------------------------------------------------------------
-- idempotency_keys: ensures safe retries for POST/PUT operations
-- key + endpoint is unique per tenant
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS idempotency_keys (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  key                TEXT NOT NULL,
  endpoint           TEXT NOT NULL,

  request_hash       TEXT NULL,
  response_json      JSONB NULL,

  status             TEXT NOT NULL DEFAULT 'recorded'
    CHECK (status IN ('recorded','completed','failed')),

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at         TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '7 days'),

  CONSTRAINT uq_idempotency UNIQUE (tenant_id, key, endpoint)
);

CREATE INDEX IF NOT EXISTS idx_idempotency_tenant_expires
  ON idempotency_keys(tenant_id, expires_at);

-- -------------------------------------------------------------------
-- outbox_events: reliable event publishing for microservices integration
-- append-only; no @Version needed
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS outbox_events (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  aggregate_type     TEXT NOT NULL,
  aggregate_id       UUID NULL,

  event_type         TEXT NOT NULL,
  payload_json       JSONB NOT NULL,

  status             TEXT NOT NULL DEFAULT 'new'
    CHECK (status IN ('new','processed','failed')),

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at       TIMESTAMPTZ NULL,

  error_message      TEXT NULL
);

CREATE INDEX IF NOT EXISTS idx_outbox_tenant_status_time
  ON outbox_events(tenant_id, status, created_at);

-- -------------------------------------------------------------------
-- audit_log: change tracking (append-only)
-- before/after JSON are optional; can be large; consider gzip in app.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  actor_user_id      UUID NULL,
  action             TEXT NOT NULL,

  entity_type        TEXT NOT NULL,
  entity_id          UUID NULL,

  before_json        JSONB NULL,
  after_json         JSONB NULL,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_tenant_time
  ON audit_log(tenant_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_audit_tenant_entity
  ON audit_log(tenant_id, entity_type, entity_id);
