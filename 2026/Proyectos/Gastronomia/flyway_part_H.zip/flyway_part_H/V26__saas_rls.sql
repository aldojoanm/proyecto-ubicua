-- Flyway V26: Part H – RLS enable + baseline tenant policies for SaaS tables
-- Uses app.current_tenant_id() from V4.
-- Note: plans are global => no tenant_id, no RLS.

ALTER TABLE subscriptions           ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices                ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_items           ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenant_credit_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenant_credit_balances  ENABLE ROW LEVEL SECURITY;

ALTER TABLE idempotency_keys        ENABLE ROW LEVEL SECURITY;
ALTER TABLE outbox_events           ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log               ENABLE ROW LEVEL SECURITY;

-- subscriptions
DROP POLICY IF EXISTS subscriptions_isolation ON subscriptions;
CREATE POLICY subscriptions_isolation ON subscriptions
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- invoices
DROP POLICY IF EXISTS invoices_isolation ON invoices;
CREATE POLICY invoices_isolation ON invoices
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- invoice_items
DROP POLICY IF EXISTS invoice_items_isolation ON invoice_items;
CREATE POLICY invoice_items_isolation ON invoice_items
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- credits
DROP POLICY IF EXISTS tenant_credit_movements_isolation ON tenant_credit_movements;
CREATE POLICY tenant_credit_movements_isolation ON tenant_credit_movements
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS tenant_credit_balances_isolation ON tenant_credit_balances;
CREATE POLICY tenant_credit_balances_isolation ON tenant_credit_balances
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- idempotency
DROP POLICY IF EXISTS idempotency_keys_isolation ON idempotency_keys;
CREATE POLICY idempotency_keys_isolation ON idempotency_keys
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- outbox
DROP POLICY IF EXISTS outbox_events_isolation ON outbox_events;
CREATE POLICY outbox_events_isolation ON outbox_events
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

-- audit
DROP POLICY IF EXISTS audit_log_isolation ON audit_log;
CREATE POLICY audit_log_isolation ON audit_log
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
