-- Flyway V24: Part H – SaaS Monetization (Plans, Subscriptions, Invoices, Credits)
-- Depends on: V2 tenants

-- -------------------------------------------------------------------
-- plans: global catalogue (not tenant-scoped). If you need tenant-specific plans, add tenant_id.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS plans (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  code               TEXT NOT NULL UNIQUE, -- e.g. FREE, PRO, ENTERPRISE
  name               TEXT NOT NULL,

  price_monthly      NUMERIC(19,4) NOT NULL DEFAULT 0,
  currency_code      CHAR(3) NOT NULL,

  limits_json        JSONB NOT NULL DEFAULT '{}'::jsonb, -- features/limits matrix

  is_active          BOOLEAN NOT NULL DEFAULT true,

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,

  version            BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_plans_active
  ON plans(is_active);

-- -------------------------------------------------------------------
-- subscriptions: tenant subscription to a plan
-- status: trial/active/past_due/cancelled
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS subscriptions (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id             UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  plan_id               UUID NOT NULL REFERENCES plans(id) ON DELETE RESTRICT,

  status               TEXT NOT NULL DEFAULT 'trial'
    CHECK (status IN ('trial','active','past_due','cancelled')),

  current_period_start TIMESTAMPTZ NOT NULL DEFAULT now(),
  current_period_end   TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '30 days'),

  cancel_at_period_end BOOLEAN NOT NULL DEFAULT false,
  cancelled_at         TIMESTAMPTZ NULL,

  -- provider integration
  provider             TEXT NULL, -- stripe/mercadopago/local
  provider_customer_ref TEXT NULL,
  provider_subscription_ref TEXT NULL,

  metadata             JSONB NULL,

  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by           UUID NULL,
  updated_at           TIMESTAMPTZ NULL,
  updated_by           UUID NULL,

  version              BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_tenant_status
  ON subscriptions(tenant_id, status);

CREATE INDEX IF NOT EXISTS idx_subscriptions_tenant_period_end
  ON subscriptions(tenant_id, current_period_end);

-- -------------------------------------------------------------------
-- invoices: issued per subscription period or ad-hoc
-- status: draft/issued/paid/void
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS invoices (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id             UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  subscription_id       UUID NULL REFERENCES subscriptions(id) ON DELETE SET NULL,

  invoice_number       TEXT NOT NULL, -- unique per tenant
  status               TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','issued','paid','void')),

  currency_code         CHAR(3) NOT NULL,

  amount_subtotal       NUMERIC(19,4) NOT NULL DEFAULT 0,
  amount_tax            NUMERIC(19,4) NOT NULL DEFAULT 0,
  amount_total          NUMERIC(19,4) NOT NULL DEFAULT 0,

  issued_at             TIMESTAMPTZ NULL,
  due_at                TIMESTAMPTZ NULL,
  paid_at               TIMESTAMPTZ NULL,

  provider              TEXT NULL,
  provider_invoice_ref  TEXT NULL,

  metadata              JSONB NULL,

  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by            UUID NULL,
  updated_at            TIMESTAMPTZ NULL,
  updated_by            UUID NULL,

  version               BIGINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_invoices_tenant_number
  ON invoices(tenant_id, invoice_number);

CREATE INDEX IF NOT EXISTS idx_invoices_tenant_status_time
  ON invoices(tenant_id, status, created_at DESC);

-- -------------------------------------------------------------------
-- invoice_items
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS invoice_items (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id             UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  invoice_id            UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,

  description          TEXT NOT NULL,
  quantity             NUMERIC(19,4) NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_amount          NUMERIC(19,4) NOT NULL DEFAULT 0,
  currency_code        CHAR(3) NOT NULL,

  amount_total         NUMERIC(19,4) NOT NULL DEFAULT 0,

  metadata             JSONB NULL,

  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by           UUID NULL,

  version              BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_invoice_items_tenant_invoice
  ON invoice_items(tenant_id, invoice_id);

-- -------------------------------------------------------------------
-- tenant_credits: wallet-style credits for the tenant (promotional credits, refunds)
-- append-like is ideal, but for simplicity we maintain balance with movements too.
-- -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tenant_credit_movements (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id             UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  movement_type        TEXT NOT NULL
    CHECK (movement_type IN ('grant','spend','refund','adjustment')),

  amount               NUMERIC(19,4) NOT NULL,
  currency_code        CHAR(3) NOT NULL,

  reference_type       TEXT NULL,
  reference_id         UUID NULL,

  notes                TEXT NULL,

  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by           UUID NULL
);

CREATE INDEX IF NOT EXISTS idx_credit_movements_tenant_time
  ON tenant_credit_movements(tenant_id, created_at DESC);

CREATE TABLE IF NOT EXISTS tenant_credit_balances (
  tenant_id            UUID PRIMARY KEY REFERENCES tenants(id) ON DELETE CASCADE,

  balance_amount       NUMERIC(19,4) NOT NULL DEFAULT 0,
  currency_code        CHAR(3) NOT NULL,

  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),

  version              BIGINT NOT NULL DEFAULT 0
);
