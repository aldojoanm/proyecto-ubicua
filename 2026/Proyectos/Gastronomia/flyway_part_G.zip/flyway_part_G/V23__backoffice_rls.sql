-- Flyway V23: Part G – RLS enable + baseline tenant policies
-- Uses app.current_tenant_id() from V4.

ALTER TABLE suppliers               ENABLE ROW LEVEL SECURITY;
ALTER TABLE ingredients             ENABLE ROW LEVEL SECURITY;
ALTER TABLE ingredient_lots         ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_balances      ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_movements     ENABLE ROW LEVEL SECURITY;

ALTER TABLE purchase_orders         ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_order_items    ENABLE ROW LEVEL SECURITY;

ALTER TABLE recipes                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE recipe_ingredients      ENABLE ROW LEVEL SECURITY;

ALTER TABLE waste_records           ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_item_consumptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS suppliers_isolation ON suppliers;
CREATE POLICY suppliers_isolation ON suppliers
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS ingredients_isolation ON ingredients;
CREATE POLICY ingredients_isolation ON ingredients
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS ingredient_lots_isolation ON ingredient_lots;
CREATE POLICY ingredient_lots_isolation ON ingredient_lots
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS inventory_balances_isolation ON inventory_balances;
CREATE POLICY inventory_balances_isolation ON inventory_balances
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS inventory_movements_isolation ON inventory_movements;
CREATE POLICY inventory_movements_isolation ON inventory_movements
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS purchase_orders_isolation ON purchase_orders;
CREATE POLICY purchase_orders_isolation ON purchase_orders
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS purchase_order_items_isolation ON purchase_order_items;
CREATE POLICY purchase_order_items_isolation ON purchase_order_items
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS recipes_isolation ON recipes;
CREATE POLICY recipes_isolation ON recipes
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS recipe_ingredients_isolation ON recipe_ingredients;
CREATE POLICY recipe_ingredients_isolation ON recipe_ingredients
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS waste_records_isolation ON waste_records;
CREATE POLICY waste_records_isolation ON waste_records
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());

DROP POLICY IF EXISTS order_item_consumptions_isolation ON order_item_consumptions;
CREATE POLICY order_item_consumptions_isolation ON order_item_consumptions
  USING (tenant_id = app.current_tenant_id())
  WITH CHECK (tenant_id = app.current_tenant_id());
