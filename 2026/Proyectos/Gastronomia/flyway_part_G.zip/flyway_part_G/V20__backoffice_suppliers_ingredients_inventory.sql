-- Flyway V20: Part G – Backoffice Core (Suppliers, Ingredients, Lots, Inventory)
-- Depends on: V2 tenants, V5 business_locations, V4 app schema for RLS

CREATE TABLE IF NOT EXISTS suppliers (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name               TEXT NOT NULL,
  phone              TEXT NULL,
  email              TEXT NULL,
  address_line       TEXT NULL,
  city               TEXT NULL,
  state              TEXT NULL,
  country_code       CHAR(2) NULL,
  metadata           JSONB NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,
  version            BIGINT NOT NULL DEFAULT 0,
  CONSTRAINT uq_supplier_name UNIQUE (tenant_id, name)
);
CREATE INDEX IF NOT EXISTS idx_suppliers_tenant_name
  ON suppliers(tenant_id, name);

CREATE TABLE IF NOT EXISTS ingredients (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name               TEXT NOT NULL,
  unit               TEXT NOT NULL,
  category           TEXT NOT NULL DEFAULT 'other'
    CHECK (category IN ('dry','cold','frozen','fresh','beverage','other')),
  is_active          BOOLEAN NOT NULL DEFAULT true,
  metadata           JSONB NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,
  version            BIGINT NOT NULL DEFAULT 0,
  CONSTRAINT uq_ingredient_name UNIQUE (tenant_id, name)
);
CREATE INDEX IF NOT EXISTS idx_ingredients_tenant_category
  ON ingredients(tenant_id, category);

CREATE TABLE IF NOT EXISTS ingredient_lots (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  ingredient_id       UUID NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  location_id         UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,
  lot_code           TEXT NULL,
  received_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at         TIMESTAMPTZ NULL,
  quantity_received  NUMERIC(19,4) NOT NULL DEFAULT 0,
  quantity_remaining NUMERIC(19,4) NOT NULL DEFAULT 0,
  unit               TEXT NOT NULL,
  metadata           JSONB NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  version            BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_lots_tenant_location_ing
  ON ingredient_lots(tenant_id, location_id, ingredient_id);
CREATE INDEX IF NOT EXISTS idx_lots_expiry
  ON ingredient_lots(tenant_id, expires_at);

CREATE TABLE IF NOT EXISTS inventory_balances (
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  location_id         UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,
  ingredient_id       UUID NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  on_hand            NUMERIC(19,4) NOT NULL DEFAULT 0,
  reserved           NUMERIC(19,4) NOT NULL DEFAULT 0,
  min_level          NUMERIC(19,4) NULL,
  unit               TEXT NOT NULL,
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  version            BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY (tenant_id, location_id, ingredient_id)
);

CREATE TABLE IF NOT EXISTS inventory_movements (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  location_id         UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,
  ingredient_id       UUID NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  lot_id              UUID NULL REFERENCES ingredient_lots(id) ON DELETE SET NULL,
  movement_type       TEXT NOT NULL
    CHECK (movement_type IN ('purchase','use','waste','adjustment','transfer_in','transfer_out','return')),
  quantity            NUMERIC(19,4) NOT NULL,
  unit               TEXT NOT NULL,
  reference_type      TEXT NULL,
  reference_id        UUID NULL,
  notes               TEXT NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,
  version             BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_inventory_movements_tenant_loc_time
  ON inventory_movements(tenant_id, location_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_inventory_movements_tenant_ing_time
  ON inventory_movements(tenant_id, ingredient_id, created_at DESC);
