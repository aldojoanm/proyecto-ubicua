-- Flyway V22: Part G – Ops hooks for "consumption by orders"
-- Links order_items to ingredients consumption snapshots.
-- Depends on: V18 order_items, V20 ingredients, V20 ingredient_lots.

CREATE TABLE IF NOT EXISTS order_item_consumptions (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  order_item_id       UUID NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,
  ingredient_id       UUID NOT NULL REFERENCES ingredients(id) ON DELETE RESTRICT,
  lot_id              UUID NULL REFERENCES ingredient_lots(id) ON DELETE SET NULL,
  quantity_used       NUMERIC(19,4) NOT NULL CHECK (quantity_used > 0),
  unit               TEXT NOT NULL,
  cost_amount         NUMERIC(19,4) NULL,
  currency_code       CHAR(3) NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,
  version             BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_oic_tenant_order_item
  ON order_item_consumptions(tenant_id, order_item_id);
CREATE INDEX IF NOT EXISTS idx_oic_tenant_ing
  ON order_item_consumptions(tenant_id, ingredient_id);
