-- Flyway V21: Part G – Purchases, Recipe BOM, Waste Records
-- Depends on: V20 suppliers/ingredients, V8 menu_items, V5 business_locations

CREATE TABLE IF NOT EXISTS purchase_orders (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  location_id         UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,
  supplier_id         UUID NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  status             TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','sent','partially_received','received','cancelled')),
  ordered_at          TIMESTAMPTZ NULL,
  expected_at         TIMESTAMPTZ NULL,
  received_at         TIMESTAMPTZ NULL,
  currency_code       CHAR(3) NOT NULL,
  notes               TEXT NULL,
  metadata            JSONB NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,
  updated_at          TIMESTAMPTZ NULL,
  updated_by          UUID NULL,
  deleted_at          TIMESTAMPTZ NULL,
  deleted_by          UUID NULL,
  version             BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_po_tenant_location_status
  ON purchase_orders(tenant_id, location_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_po_tenant_supplier
  ON purchase_orders(tenant_id, supplier_id, created_at DESC);

CREATE TABLE IF NOT EXISTS purchase_order_items (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  purchase_order_id   UUID NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  ingredient_id       UUID NOT NULL REFERENCES ingredients(id) ON DELETE RESTRICT,
  quantity_ordered    NUMERIC(19,4) NOT NULL,
  quantity_received   NUMERIC(19,4) NOT NULL DEFAULT 0,
  unit               TEXT NOT NULL,
  unit_price         NUMERIC(19,4) NULL,
  currency_code      CHAR(3) NOT NULL,
  lot_id             UUID NULL REFERENCES ingredient_lots(id) ON DELETE SET NULL,
  metadata           JSONB NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  version            BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_po_items_tenant_po
  ON purchase_order_items(tenant_id, purchase_order_id);
CREATE INDEX IF NOT EXISTS idx_po_items_tenant_ing
  ON purchase_order_items(tenant_id, ingredient_id);

CREATE TABLE IF NOT EXISTS recipes (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  menu_item_id        UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
  name               TEXT NULL,
  yield_qty          NUMERIC(19,4) NOT NULL DEFAULT 1 CHECK (yield_qty > 0),
  is_active          BOOLEAN NOT NULL DEFAULT true,
  notes              TEXT NULL,
  metadata           JSONB NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  deleted_at         TIMESTAMPTZ NULL,
  deleted_by         UUID NULL,
  version            BIGINT NOT NULL DEFAULT 0,
  CONSTRAINT uq_recipe_menu_item UNIQUE (tenant_id, menu_item_id)
);
CREATE INDEX IF NOT EXISTS idx_recipes_tenant_menu_item
  ON recipes(tenant_id, menu_item_id);

CREATE TABLE IF NOT EXISTS recipe_ingredients (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  recipe_id           UUID NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  ingredient_id       UUID NOT NULL REFERENCES ingredients(id) ON DELETE RESTRICT,
  quantity            NUMERIC(19,4) NOT NULL CHECK (quantity > 0),
  unit               TEXT NOT NULL,
  waste_factor        NUMERIC(6,5) NOT NULL DEFAULT 0 CHECK (waste_factor >= 0 AND waste_factor <= 1),
  metadata           JSONB NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by         UUID NULL,
  updated_at         TIMESTAMPTZ NULL,
  updated_by         UUID NULL,
  version            BIGINT NOT NULL DEFAULT 0,
  CONSTRAINT uq_recipe_ingredient UNIQUE (tenant_id, recipe_id, ingredient_id)
);
CREATE INDEX IF NOT EXISTS idx_recipe_ing_tenant_recipe
  ON recipe_ingredients(tenant_id, recipe_id);
CREATE INDEX IF NOT EXISTS idx_recipe_ing_tenant_ing
  ON recipe_ingredients(tenant_id, ingredient_id);

CREATE TABLE IF NOT EXISTS waste_records (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  location_id         UUID NOT NULL REFERENCES business_locations(id) ON DELETE CASCADE,
  ingredient_id       UUID NOT NULL REFERENCES ingredients(id) ON DELETE RESTRICT,
  lot_id              UUID NULL REFERENCES ingredient_lots(id) ON DELETE SET NULL,
  quantity            NUMERIC(19,4) NOT NULL CHECK (quantity > 0),
  unit               TEXT NOT NULL,
  reason_code         TEXT NOT NULL
    CHECK (reason_code IN ('expired','prep_error','returned','spoilage','other')),
  notes               TEXT NULL,
  recorded_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  recorded_by         UUID NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID NULL,
  version             BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_waste_tenant_loc_time
  ON waste_records(tenant_id, location_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_waste_tenant_ing_time
  ON waste_records(tenant_id, ingredient_id, recorded_at DESC);
